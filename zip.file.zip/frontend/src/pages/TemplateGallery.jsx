import { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  fetchResumeTemplates,
  createMyResume,
  fetchAiStatus,
} from "../services/api";
import { readForUser, writeForUser } from "../services/sessionCache";
import ResumePreview from "../components/ResumePreview";
import "./TemplateGallery.css";

/**
 * The template library.
 *
 * How many templates exist is decided by the server and reported
 * here; this page never counts cards in the DOM, because that would
 * be the number it happens to have drawn rather than the number
 * there are. Filtering, searching, sorting and paging all happen
 * server-side for the same reason: two browsers must not get
 * different answers to "how many are there".
 */

const PAGE_SIZE = 24;

/**
 * Favourites are a per-account UI preference, not resume content.
 *
 * They live in the session cache under this name, which is already
 * namespaced per user id, so one person on a shared machine does not
 * inherit another's shortlist. Nothing is sent to the server: the
 * catalogue is public, so a favourite list is not worth a table.
 */
const FAVOURITES = "template_favourites";

function readFavourites(userId) {
  const stored = readForUser(FAVOURITES, userId, []);
  return Array.isArray(stored) ? stored : [];
}

export default function TemplateGallery() {
  const navigate = useNavigate();

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [ai, setAi] = useState(null);

  // Filters. `offset` drives paging; everything else narrows.
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const [category, setCategory] = useState("all");
  const [experience, setExperience] = useState("all");
  const [columns, setColumns] = useState("all");
  const [header, setHeader] = useState("all");
  const [sectionStyle, setSectionStyle] = useState("all");
  const [atsOnly, setAtsOnly] = useState(false);
  const [sort, setSort] = useState("featured");

  const [shown, setShown] = useState([]);
  const [total, setTotal] = useState(0);
  const [loadingMore, setLoadingMore] = useState(false);
  const [preview, setPreview] = useState(null);
  const [creating, setCreating] = useState("");

  // Lazy initialiser: read the account id once, the same way the
  // rest of the app does, rather than from an effect.
  const [userId] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("resumeai_user") || "{}").id
        ?? null;
    } catch {
      return null;
    }
  });

  const [favourites, setFavourites] = useState(() =>
    readFavourites(userId)
  );
  const [favouritesOnly, setFavouritesOnly] = useState(false);

  // Debounce so typing does not fire a request per keystroke.
  useEffect(() => {
    const timer = setTimeout(() => setDebounced(query), 250);
    return () => clearTimeout(timer);
  }, [query]);

  // Pure: builds the query, fetches, returns the payload. It sets no
  // state, so it can be called from an effect body without a
  // cascading render.
  const fetchPage = useCallback(
    async (offset) => {
      const params = new URLSearchParams({
        limit: String(PAGE_SIZE),
        offset: String(offset),
        sort,
      });

      if (debounced.trim()) params.set("q", debounced.trim());
      if (category !== "all") params.set("category", category);
      if (experience !== "all") params.set("experience", experience);
      if (columns !== "all") params.set("columns", columns);
      if (header !== "all") params.set("header", header);
      if (sectionStyle !== "all") {
        params.set("section_style", sectionStyle);
      }
      if (atsOnly) params.set("ats", "1");

      return fetchResumeTemplates(params);
    },
    [debounced, category, experience, columns, header, sectionStyle,
     atsOnly, sort]
  );

  const applyPage = useCallback((payload, append) => {
    setData(payload);
    setTotal(payload.total);
    setShown((previous) =>
      append ? [...previous, ...payload.templates]
             : payload.templates
    );
    setError("");
  }, []);

  const reportError = useCallback((requestError) => {
    setError(
      requestError?.message || "Could not load the template library."
    );
  }, []);

  // Any filter change resets paging to the first page.
  useEffect(() => {
    let cancelled = false;

    fetchPage(0)
      .then((payload) => {
        if (cancelled) return;
        applyPage(payload, false);
      })
      .catch((requestError) => {
        if (cancelled) return;
        reportError(requestError);
      })
      .finally(() => {
        if (cancelled) return;
        setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [fetchPage, applyPage, reportError]);

  async function loadMore() {
    setLoadingMore(true);

    try {
      const payload = await fetchPage(shown.length);
      applyPage(payload, true);
    } catch (requestError) {
      reportError(requestError);
    } finally {
      setLoadingMore(false);
    }
  }

  useEffect(() => {
    fetchAiStatus()
      .then(setAi)
      .catch(() => {
        /* the gallery works without the AI badge */
      });
  }, []);

  const favouritesSet = useMemo(
    () => new Set(favourites),
    [favourites]
  );

  const visible = useMemo(() => {
    if (!favouritesOnly) return shown;
    return shown.filter((t) => favouritesSet.has(t.key));
  }, [shown, favouritesOnly, favouritesSet]);

  function toggleFavourite(key) {
    setFavourites((previous) => {
      const next = previous.includes(key)
        ? previous.filter((k) => k !== key)
        : [...previous, key];

      writeForUser(FAVOURITES, userId, next, []);

      return next;
    });
  }

  async function handleUse(template) {
    setCreating(template.key);

    try {
      const created = await createMyResume({
        title: `${template.name} Resume`,
        templateKey: template.key,
        startEmpty: true,
      });

      if (created) navigate(`/resume-builder/${created.id}`);
    } catch (requestError) {
      setError(
        requestError?.message || "Could not start that resume."
      );
    } finally {
      setCreating("");
    }
  }

  function resetFilters() {
    setQuery("");
    setDebounced("");
    setCategory("all");
    setExperience("all");
    setColumns("all");
    setHeader("all");
    setSectionStyle("all");
    setAtsOnly(false);
    setFavouritesOnly(false);
    setSort("featured");
  }

  const facets = data?.facets;
  const hasFilters =
    debounced.trim() || category !== "all" || experience !== "all" ||
    columns !== "all" || header !== "all" || sectionStyle !== "all" ||
    atsOnly || favouritesOnly;

  if (loading && !data) {
    return (
      <div className="tg-page">
        <div className="tg-card tg-state">
          <div className="spinner" />
          <p>Loading the template library…</p>
        </div>
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="tg-page">
        <div className="tg-card tg-state">
          <h2>Could not load the library</h2>
          <p className="tg-error">{error}</p>
          <div className="tg-state-actions">
            <button
              type="button"
              className="tg-btn"
              onClick={() => window.location.reload()}
            >
              Try again
            </button>
            <Link to="/dashboard" className="tg-btn tg-btn-ghost">
              Back to dashboard
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="tg-page">
      <header className="tg-header">
        <div>
          <Link to="/dashboard" className="tg-back">
            ← Back to dashboard
          </Link>
          <h1>Resume Templates</h1>
          <p className="tg-sub">
            Every design below is drawn from a real layout, not a
            picture of one. Pick one, fill in your details, then
            download a PDF with selectable text.
          </p>
        </div>

        <div className="tg-header-actions">
          <Link to="/my-resumes" className="tg-btn tg-btn-ghost">
            My saved resumes
          </Link>
        </div>
      </header>

      <div className="tg-flow" aria-label="How this works">
        <span className="tg-flow-step">1 Choose Template</span>
        <span className="tg-flow-arrow">→</span>
        <span className="tg-flow-step">2 Enter Details</span>
        <span className="tg-flow-arrow">→</span>
        <span className="tg-flow-step">3 Customise</span>
        <span className="tg-flow-arrow">→</span>
        <span className="tg-flow-step">4 Preview</span>
        <span className="tg-flow-arrow">→</span>
        <span className="tg-flow-step">5 Download PDF</span>
      </div>

      {/* The count comes from the server's registry, not from the
          number of cards that happen to be on screen. */}
      <p className="tg-count-line">
        <strong>{facets?.total ?? total}</strong> templates
        {" · "}
        {facets?.ats_count ?? 0} ATS-friendly
        {hasFilters && (
          <>
            {" · "}
            <strong>{total}</strong> matching your filters
          </>
        )}
      </p>

      <div className="tg-toolbar">
        <input
          type="search"
          className="tg-search"
          placeholder="Search by name, style or role…"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          aria-label="Search templates"
        />

        {/*
          Columns is the first question people actually ask about a
          layout, so it gets its own row of chips rather than hiding
          in a dropdown. The previous "Layout" menu offered ninety-two
          composed labels, which is not a menu anyone can read.
        */}
        <div className="tg-columns" role="group" aria-label="Columns">
          <button
            type="button"
            className={`tg-chip ${
              columns === "all" ? "active" : ""
            }`}
            onClick={() => setColumns("all")}
          >
            Any columns ({facets?.total ?? 0})
          </button>
          {(facets?.columns || []).map((item) => (
            <button
              key={item.key}
              type="button"
              className={`tg-chip ${
                columns === item.key ? "active" : ""
              }`}
              onClick={() => setColumns(item.key)}
            >
              {item.label} ({item.count})
            </button>
          ))}
        </div>

        <div className="tg-filters">
          <button
            type="button"
            className={`tg-chip ${category === "all" ? "active" : ""}`}
            onClick={() => setCategory("all")}
          >
            All categories
          </button>

          {(facets?.categories || []).map((item) => (
            <button
              key={item.key}
              type="button"
              className={`tg-chip ${
                category === item.key ? "active" : ""
              }`}
              onClick={() => setCategory(item.key)}
              title={item.blurb}
            >
              {item.label} ({item.count})
            </button>
          ))}
        </div>

        <div className="tg-selects">
          <label className="tg-select">
            <span>Header style</span>
            <select
              value={header}
              onChange={(event) => setHeader(event.target.value)}
            >
              <option value="all">Any header</option>
              {(facets?.headers || []).map((item) => (
                <option key={item.key} value={item.key}>
                  {item.label} ({item.count})
                </option>
              ))}
            </select>
          </label>

          <label className="tg-select">
            <span>Section style</span>
            <select
              value={sectionStyle}
              onChange={(event) => setSectionStyle(event.target.value)}
            >
              <option value="all">Any section style</option>
              {(facets?.section_styles || []).map((item) => (
                <option key={item.key} value={item.key}>
                  {item.label} ({item.count})
                </option>
              ))}
            </select>
          </label>

          <label className="tg-select">
            <span>Experience</span>
            <select
              value={experience}
              onChange={(event) => setExperience(event.target.value)}
            >
              <option value="any">Any experience</option>
              {(facets?.experience_levels || []).map((item) => (
                <option key={item.key} value={item.key}>
                  {item.label} ({item.count})
                </option>
              ))}
            </select>
          </label>

          <label className="tg-select">
            <span>Sort</span>
            <select
              value={sort}
              onChange={(event) => setSort(event.target.value)}
            >
              {(facets?.sorts || []).map((item) => (
                <option key={item.key} value={item.key}>
                  {item.label}
                </option>
              ))}
            </select>
          </label>

          <label className="tg-toggle">
            <input
              type="checkbox"
              checked={atsOnly}
              onChange={(event) => setAtsOnly(event.target.checked)}
            />
            <span>ATS-friendly only</span>
          </label>

          <label className="tg-toggle">
            <input
              type="checkbox"
              checked={favouritesOnly}
              onChange={(event) => setFavouritesOnly(event.target.checked)}
            />
            <span>Favourites ({favourites.length})</span>
          </label>
        </div>

        {hasFilters && (
          <button
            type="button"
            className="tg-btn tg-btn-small tg-btn-ghost"
            onClick={resetFilters}
          >
            Clear filters
          </button>
        )}
      </div>

      {error && <p className="tg-error tg-error-inline">{error}</p>}

      <div className="tg-grid">
        {visible.map((template) => {
          const isFavourite = favouritesSet.has(template.key);

          return (
            <article
              key={template.key}
              className={`tg-card tg-tile ${
                preview?.key === template.key ? "selected" : ""
              }`}
            >
              <div className="tg-tile-frame">
                <button
                  type="button"
                  className="tg-tile-preview"
                  onClick={() => setPreview(template)}
                  aria-label={`Preview ${template.name}`}
                >
                  {/*
                    A miniature of the real page rather than a crop.
                    The sheet is sized in em units, so setting the
                    font-size here scales the whole layout down
                    intact - which is what makes the thumbnail match
                    the exported PDF instead of merely resembling it.
                  */}
                  <span className="tg-thumb">
                    <ResumePreview
                      content={template.sample}
                      template={template}
                      settings={{
                        accent: template.default_accent,
                        font: template.default_font,
                      }}
                      emptyLabel=""
                    />
                  </span>
                </button>

                <button
                  type="button"
                  className={`tg-fav ${
                    isFavourite ? "active" : ""
                  }`}
                  onClick={() => toggleFavourite(template.key)}
                  aria-pressed={isFavourite}
                  aria-label={
                    isFavourite
                      ? `Remove ${template.name} from favourites`
                      : `Add ${template.name} to favourites`
                  }
                  title={
                    isFavourite ? "Remove from favourites"
                                : "Add to favourites"
                  }
                >
                  {isFavourite ? "★" : "☆"}
                </button>
              </div>

              <div className="tg-tile-body">
                <div className="tg-tile-head">
                  <h2 className="tg-tile-name">{template.name}</h2>
                  {template.ats_friendly && (
                    <span className="tg-badge tg-badge-ats">ATS</span>
                  )}
                </div>

                <p className="tg-tile-cat">
                  <span className="tg-cat-pill">
                    {template.category_label}
                  </span>
                  <span className="tg-tile-layout">
                    {template.layout_label}
                  </span>
                </p>
                <p className="tg-tile-desc">{template.description}</p>

                {template.best_for && (
                  <p className="tg-tile-best">
                    <strong>Best for:</strong> {template.best_for}
                  </p>
                )}

                <div className="tg-tile-actions">
                  <button
                    type="button"
                    className="tg-btn tg-btn-small"
                    onClick={() => handleUse(template)}
                    disabled={creating === template.key}
                  >
                    {creating === template.key
                      ? "Starting…"
                      : "Use This Template"}
                  </button>
                  <button
                    type="button"
                    className="tg-btn tg-btn-small tg-btn-ghost"
                    onClick={() => setPreview(template)}
                  >
                    Preview
                  </button>
                </div>
              </div>
            </article>
          );
        })}
      </div>

      {visible.length === 0 && (
        <div className="tg-card tg-empty">
          {favouritesOnly && shown.length === 0 ? (
            <>
              <h2>No templates to show</h2>
              <p>
                The current filters match nothing at all, so there is
                nothing to pick out of. Clear the filters first, then
                tap the star on a few designs you like.
              </p>
            </>
          ) : favouritesOnly ? (
            <>
              <h2>None of these are favourites yet</h2>
              <p>
                Tap the star on any template to add it. Favourites
                are kept on your account only.
              </p>
            </>
          ) : (
            <>
              <h2>No templates match “{debounced}”</h2>
              <p>
                Nothing in the {total} registered templates matches
                every filter you have set. Try removing one - the
                columns and style filters are the narrowest.
              </p>
            </>
          )}

          <button
            type="button"
            className="tg-btn"
            onClick={resetFilters}
          >
            Clear all filters
          </button>
        </div>
      )}

      {shown.length < total && (
        <div className="tg-more">
          <button
            type="button"
            className="tg-btn"
            onClick={() => loadMore()}
            disabled={loadingMore}
          >
            {loadingMore
              ? "Loading…"
              : `Show more (${shown.length} of ${total})`}
          </button>
        </div>
      )}

      {facets && data.disclaimer && (
        <p className="tg-disclaimer">{data.disclaimer}</p>
      )}

      {ai && !ai.configured && (
        <p className="tg-disclaimer">
          Writing suggestions are currently generated from your own
          resume text. Adding a Gemini API key enables richer{" "}
          <Link to="/dashboard">model-written suggestions</Link>.
        </p>
      )}

      {/*
        The modal renders only when the user asked for a specific
        preview. It used to fall back to the first template in the
        filtered list, which meant it covered the entire gallery on
        page load and could never be dismissed.
      */}
      {preview && (
        <div
          className="tg-modal"
          role="dialog"
          aria-modal="true"
          aria-label={`${preview.name} preview`}
          onClick={() => setPreview(null)}
        >
          <div
            className="tg-modal-inner"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="tg-modal-head">
              <div>
                <h2 className="tg-modal-name">{preview.name}</h2>
                <p className="tg-modal-cat">
                  {preview.category_label} · {preview.layout_label}
                  {preview.ats_friendly ? " · ATS-friendly layout" : ""}
                </p>
              </div>
              <button
                type="button"
                className="tg-btn tg-btn-small tg-btn-ghost"
                onClick={() => setPreview(null)}
                aria-label="Close preview"
              >
                Close
              </button>
            </div>

            <div className="tg-modal-preview">
              <ResumePreview
                content={preview.sample}
                template={preview}
                settings={{
                  accent: preview.default_accent,
                  font: preview.default_font,
                }}
                emptyLabel=""
              />
            </div>

            <p className="tg-disclaimer">
              This preview uses fictional sample data so you can see
              the layout. It is never merged into your own resume.
            </p>

            <div className="tg-modal-actions">
              <button
                type="button"
                className="tg-btn"
                onClick={() => handleUse(preview)}
                disabled={creating === preview.key}
              >
                Use This Template
              </button>
              <button
                type="button"
                className={`tg-btn tg-btn-ghost ${
                  favouritesSet.has(preview.key) ? "is-fav" : ""
                }`}
                onClick={() => toggleFavourite(preview.key)}
              >
                {favouritesSet.has(preview.key)
                  ? "★ Favourited"
                  : "☆ Add to favourites"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}