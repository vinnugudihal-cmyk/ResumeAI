﻿import { useEffect } from "react";
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
  useLocation,
  useNavigate,
} from "react-router-dom";

import Home from "./pages/Home";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import CareerProfile from "./pages/CareerProfile";
import CareerMission from "./pages/CareerMission";
import TemplateGallery from "./pages/TemplateGallery";
import ResumeBuilder from "./pages/ResumeBuilder";
import MyResumes from "./pages/MyResumes";
import FindJobs from "./pages/FindJobs";
import SkillPassport from "./pages/SkillPassport";
import Applications from "./pages/Applications";
import { onAuthFailure } from "./services/api";
import { clearAuthState } from "./services/authSession";
import { SessionProvider } from "./services/sessionContext";
import { useSession as useSessionContext } from "./services/sessionStore";

/**
 * Asks the backend who the current session belongs to.
 *
 * This used to be a plain hook that each caller ran for itself,
 * which meant opening the root URL fired three parallel `/auth/me`
 * requests and spent most of a second on "Checking your session..."
 * before it could decide. It is a provider now - see
 * sessionContext.jsx - and the check runs once per page load.
 */
function useSession() {
  return useSessionContext();
}

/** Shown while the session is being checked. */
function CheckingSession() {
  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: "14px",
        fontFamily: "Inter, -apple-system, sans-serif",
        color: "#788194",
        background: "#f8faff",
      }}
    >
      <div
        className="spinner"
        style={{
          width: "30px",
          height: "30px",
          border: "3px solid #e5e7ee",
          borderTopColor: "#3155d9",
          borderRadius: "50%",
          animation: "spin 0.8s linear infinite",
        }}
      />
      <p style={{ margin: 0, fontSize: "15px" }}>
        Checking your session...
      </p>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

/**
 * Sends the user to Login the moment the server reports the session
 * is gone.
 *
 * RequireAuth only checks once, when a page mounts. Without this,
 * a session that expires while somebody is already on a page left
 * them sitting on a protected screen that could no longer load
 * anything, and nothing told them why.
 *
 * Lives inside the Router so it can use the navigator.
 */
function AuthFailureWatcher() {
  const navigate = useNavigate();

  useEffect(() => {
    return onAuthFailure(() => {
      // Drop cached state before navigating, so nothing private is
      // rendered on the way out.
      clearAuthState();

      // replace, so the protected page is not left in history for
      // the Back button to return to.
      navigate("/login", { replace: true });
    });
  }, [navigate]);

  return null;
}

/**
 * Blocks a page until we know whether a session exists.
 */
function RequireAuth({ children }) {
  const location = useLocation();
  const { loading, user } = useSession();

  if (loading) {
    return <CheckingSession />;
  }

  if (!user) {
    // Remember where they were heading so login can return them.
    return (
      <Navigate
        to="/login"
        replace
        state={{ from: location.pathname }}
      />
    );
  }

  return children;
}

/**
 * The root URL is the front door for the session:
 *   signed in  -> straight to the dashboard
 *   signed out -> straight to Student Login
 *
 * The Home page is untouched and still lives at /home.
 */
function RootRedirect() {
  const { loading, user } = useSession();

  if (loading) {
    return <CheckingSession />;
  }

  return (
    <Navigate to={user ? "/dashboard" : "/login"} replace />
  );
}

function App() {
  return (
    <BrowserRouter>
      {/* One session for the whole app, and the inactivity clock
          that ends it. */}
      <SessionProvider>
        {/* Mounted once, ahead of the guarded pages. */}
        <AuthFailureWatcher />

      <Routes>
        {/* Root now leads to Login, or the Dashboard when signed in */}
        <Route path="/" element={<RootRedirect />} />

        {/* Student Login / Register */}
        <Route path="/login" element={<Login />} />

        {/* ResumeAI Dashboard - login required */}
        <Route
          path="/dashboard"
          element={
            <RequireAuth>
              <Dashboard />
            </RequireAuth>
          }
        />

        {/* Career Profile - login required */}
        <Route
          path="/career-profile"
          element={
            <RequireAuth>
              <CareerProfile />
            </RequireAuth>
          }
        />

        {/* Career Mission - login required */}
        <Route
          path="/career-mission"
          element={
            <RequireAuth>
              <CareerMission />
            </RequireAuth>
          }
        />

        {/* Find Jobs - login required */}
        <Route
          path="/find-jobs"
          element={
            <RequireAuth>
              <FindJobs />
            </RequireAuth>
          }
        />

        {/* Saved Jobs - the same page, opened on the saved list */}
        <Route
          path="/saved-jobs"
          element={
            <RequireAuth>
              <FindJobs initialTab="saved" />
            </RequireAuth>
          }
        />

        {/* Skill Passport - login required */}
        <Route
          path="/skill-passport"
          element={
            <RequireAuth>
              <SkillPassport />
            </RequireAuth>
          }
        />

        {/* Application Tracker - login required */}
        <Route
          path="/applications"
          element={
            <RequireAuth>
              <Applications />
            </RequireAuth>
          }
        />

        {/* Resume Studio: browse templates without an account */}
        <Route
          path="/resume-templates"
          element={<TemplateGallery />}
        />

        {/* Saved resumes and the editor - login required */}
        <Route
          path="/my-resumes"
          element={
            <RequireAuth>
              <MyResumes />
            </RequireAuth>
          }
        />

        <Route
          path="/resume-builder/:resumeId"
          element={
            <RequireAuth>
              <ResumeBuilder />
            </RequireAuth>
          }
        />

        {/* Home page is kept, it is just no longer the landing page */}
        <Route path="/home" element={<Home />} />

        {/* Fallback */}
        <Route
          path="*"
          element={<Navigate to="/" replace />}
        />
      </Routes>
      </SessionProvider>
    </BrowserRouter>
  );
}

export default App;
