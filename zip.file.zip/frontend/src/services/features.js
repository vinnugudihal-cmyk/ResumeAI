/**
 * The features this app has, in one place.
 *
 * The sidebar, the dashboard launch grid and the "coming soon"
 * list all read from here. They used to be written out separately,
 * which is how a button ends up pointing at a page that does not
 * exist: the link looked fine in the sidebar and 404'd when it
 * was clicked.
 *
 * Every entry here is backed by a real route in App.jsx and a real
 * backend feature. Nothing is listed that the app cannot do.
 *
 * `PRIMARY` is the one full-width card above the grid: building a
 * resume. Resume Templates lives inside it rather than beside it,
 * because choosing a design and writing the content are the same
 * journey and two cards for it sent people to the same gallery.
 */

export const PRIMARY = {
  key: "create_resume",
  label: "Create My Resume",
  icon: "create",
  blurb:
    "Pick one of 122 designs, fill in your own details, and "
    + "download a PDF with selectable text.",
  to: "/resume-templates",
  kind: "page",
};

export const FEATURES = [
  {
    key: "resume_analysis",
    label: "Analyse My Resume",
    icon: "analyse",
    blurb:
      "Upload a PDF and get an honest ATS and content score, "
      + "with every gap explained.",
    to: "/dashboard",
    anchor: "analysis-section",
    kind: "section",
  },
  {
    key: "find_jobs",
    label: "Find Jobs",
    icon: "jobs",
    blurb:
      "Search real job sites by role, city, experience level and "
      + "work arrangement.",
    to: "/find-jobs",
    kind: "page",
  },
  {
    key: "career_mission",
    label: "My Career Mission",
    icon: "mission",
    blurb:
      "A step-by-step plan for the role you are aiming at, built "
      + "from your own profile.",
    to: "/career-mission",
    kind: "page",
  },
  {
    key: "applications",
    label: "Track Applications",
    icon: "applications",
    blurb:
      "See where every application you sent actually stands, and "
      + "what to chase.",
    to: "/applications",
    kind: "page",
  },
  {
    key: "jd_match",
    label: "Match a Job Description",
    icon: "match",
    blurb:
      "Paste a job description and see which of your skills it "
      + "asks for and which you are missing.",
    to: "/dashboard",
    anchor: "analysis-section",
    kind: "section",
  },
  {
    key: "career_profile",
    label: "My Career Profile",
    icon: "profile",
    blurb:
      "Education, projects and skills you have told us about, in "
      + "one reusable place.",
    to: "/career-profile",
    kind: "page",
  },
  {
    key: "skill_passport",
    label: "My Skill Passport",
    icon: "skills",
    blurb:
      "Track real evidence for each skill you claim, so the claim "
      + "is worth something.",
    to: "/skill-passport",
    kind: "page",
  },
  {
    key: "saved_jobs",
    label: "Saved Jobs",
    icon: "saved",
    blurb:
      "The jobs you kept, ready to track or tailor a resume for.",
    to: "/saved-jobs",
    kind: "page",
  },
];

/**
 * Short labels for the sidebar.
 *
 * The full label is what the dashboard card needs. In a 216px rail
 * "Match a Job Description" wrapped onto two lines and left the
 * menu looking ragged, so the menu gets its own word where the two
 * differ. Where they are the same, `navLabel` is simply not set and
 * the sidebar falls back to `label`.
 */
export const NAV_LABELS = {
  resume_analysis: "Analyse Resume",
  find_jobs: "Find Jobs",
  career_mission: "Career Mission",
  applications: "Applications",
  jd_match: "Match a Job",
  career_profile: "Career Profile",
  skill_passport: "Skill Passport",
  saved_jobs: "Saved Jobs",
  resume_templates: "Templates",
  resume_studio: "My Resumes",
};

export function navLabelFor(feature) {
  return NAV_LABELS[feature.key] || feature.label;
}

export const FEATURE_BY_KEY = FEATURES.reduce((all, feature) => {
  all[feature.key] = feature;

  return all;
}, {});

/**
 * Where a card goes, anchor included.
 *
 * Two cards share the analysis section on purpose: uploading a
 * resume to score it and pasting a job description to match against
 * it are two different jobs done in one panel. They are not given
 * separate destinations because there is only one place they are
 * actually done.
 */
export function destinationFor(feature) {
  if (!feature.anchor) return feature.to;

  return `${feature.to}#${feature.anchor}`;
}

/**
 * Things the app deliberately does not do yet.
 *
 * Listed as disabled and labelled "Coming soon" rather than
 * rendered as a button, because a button that leads nowhere is
 * worse than an honest gap.
 */
export const COMING_SOON = [
  {
    label: "Cover letter builder",
    note: "Not built yet. Writing one that sounds like you rather "
      + "than a template is worth doing properly.",
  },
  {
    label: "Mock interview questions",
    note: "Not built yet. Planned alongside Career Mission.",
  },
  {
    label: "Salary negotiation coach",
    note: "Not built yet. Would need real market data first, "
      + "which this app does not have.",
  },
];