﻿"""
ResumeAI API service.

Routes
------
GET    /                service banner
GET    /health          health + database readiness
POST   /analyze         upload a resume PDF (and optional job
                       description), analyse it, store it
GET    /analyses        list stored analyses, newest first
GET    /analyses/<id>   one stored analysis, full detail
DELETE /analyses/<id>   delete a stored analysis

The /analyze response keeps every field the React dashboard
already reads, so the frontend does not need to change.
"""

import os
import re
import secrets
import tempfile
import uuid
from functools import wraps

from flask import (
    Flask, request, jsonify, session
)
from flask_cors import CORS
from werkzeug.security import (
    generate_password_hash, check_password_hash
)
from werkzeug.utils import secure_filename

from extractor import extract_text_detailed, friendly_error
from analyzer import analyze_resume
from roles import list_roles
import database
import migrations
import career_profile
import mission
import templates_catalog as templates
import resume_builder
import resume_pdf
import resume_ai
import jobs
import passport
import tracker
import career_ai

app = Flask(__name__)

# ---------------------------------------------------------
# CONFIGURATION
# ---------------------------------------------------------

# Sessions are same-origin friendly. The React dev server calls
# this service on a different port, so credentials are allowed.
# expose_headers lets the browser read the filename it is given
# back, which the PDF download link relies on. The credential and
# SameSite rules are unchanged, so this widens nothing that is not
# already reachable with the session cookie.
CORS(
    app,
    supports_credentials=True,
    expose_headers=["Content-Disposition", "Content-Length"],
)

# Maximum upload size: 5 MB
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024

# Session cookie settings. HttpOnly keeps the session out of
# reach of any script on the page. Lax is what makes the cookie
# survive a top-level navigation while still not riding along on a
# cross-site form post.
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

# Secure only where there is HTTPS. Setting it unconditionally makes
# the cookie silently vanish on http://localhost, which is where
# this runs in development, and the symptom is a login that appears
# to succeed and then bounces straight back to the login page.
#
# Behind TLS, set RESUMEAI_HTTPS=1 (or run behind a proxy that sets
# X-Forwarded-Proto) and the cookie is marked Secure.
app.config["SESSION_COOKIE_SECURE"] = (
    os.environ.get("RESUMEAI_HTTPS", "").strip().lower()
    in ("1", "true", "yes", "on")
)

# Absolute lifetime. The frontend also ends a session after
# RESUMEAI_IDLE_MINUTES of no activity; this is the backstop for a
# cookie that is never opened again.
#
# It was seven days, which on a shared computer meant the next
# person to open the app was still signed in as the last one.
app.config["PERMANENT_SESSION_LIFETIME"] = int(
    os.environ.get("RESUMEAI_SESSION_HOURS", "12")
) * 60 * 60

# Refresh the cookie on every request, so an active user is not
# logged out mid-edit, and an idle one is.
app.config["SESSION_REFRESH_EACH_REQUEST"] = True

# Idle timeout, in minutes, recorded in the session so the
# /auth/me response can tell the client how long it is willing to
# stay signed in. The client enforces it; this is what it is told.
app.config["RESUMEAI_IDLE_MINUTES"] = int(
    os.environ.get("RESUMEAI_IDLE_MINUTES", "15")
)

app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024


def _load_secret_key():
    """
    Use RESUMEAI_SECRET_KEY when provided. Otherwise reuse a
    locally generated key so sessions survive a restart during
    development. The key never leaves the machine and is not
    stored in the database.
    """

    env_key = os.environ.get("RESUMEAI_SECRET_KEY")

    if env_key and env_key.strip():
        return env_key.strip()

    key_file = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        ".secret_key"
    )

    try:
        if os.path.exists(key_file):
            with open(key_file, "r", encoding="utf-8") as handle:
                stored = handle.read().strip()

            if stored:
                return stored

        generated = secrets.token_hex(32)

        with open(key_file, "w", encoding="utf-8") as handle:
            handle.write(generated)

        return generated

    except OSError as error:
        print(
            "Could not persist session key, using a "
            "temporary one:", error
        )
        return secrets.token_hex(32)


app.secret_key = _load_secret_key()

ALLOWED_EXTENSIONS = {".pdf"}

MIN_PASSWORD_LENGTH = 8

# A deliberately plain check, not RFC 5322. The point is to catch an
# address that is obviously not one - "@example.com" and
# "missing@tld" both passed the old test, which only asked for an
# "@" somewhere and a "." after the last one.
_EMAIL_LOCAL = re.compile(r"^[A-Za-z0-9._%+-]+$")
_EMAIL_DOMAIN = re.compile(
    r"^(?:[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?\.)+"
    r"[A-Za-z]{2,}$"
)


def _is_valid_email(value):
    """
    A shape check, not a delivery check.

    Nothing here sends mail, so this cannot tell you the address
    exists - only that it is written like one. Do not describe it as
    a verification: a user can type somebody else's address and it
    will be accepted, which is why email confirmation is a separate
    step that this app does not currently perform.
    """

    if not value or value.count("@") != 1:
        return False

    local, _, domain = value.partition("@")

    if len(local) > 64 or len(value) > 254:
        return False

    if not _EMAIL_LOCAL.match(local):
        return False

    return bool(_EMAIL_DOMAIN.match(domain))

# Uploaded PDFs are kept here so an analysis can be traced back
# to the exact file that produced it.
UPLOAD_DIR = os.environ.get(
    "RESUMEAI_UPLOADS",
    os.path.join(os.path.dirname(os.path.abspath(__file__)),
                 "uploads")
)

os.makedirs(UPLOAD_DIR, exist_ok=True)

PDF_MAGIC = b"%PDF"


# ---------------------------------------------------------
# HELPERS
# ---------------------------------------------------------

def looks_like_pdf(head_bytes):
    """
    Confirm the upload really is a PDF by checking its magic
    bytes, so a renamed file cannot slip through.
    """

    return head_bytes[:4] == PDF_MAGIC


def save_upload(file_storage, original_name):
    """
    Store the upload under a random safe name. The client
    filename is never used to build a path.
    """

    safe_name = secure_filename(original_name or "resume.pdf")

    if not safe_name:
        safe_name = "resume.pdf"

    stored_name = f"{uuid.uuid4().hex}.pdf"

    stored_path = os.path.join(UPLOAD_DIR, stored_name)

    file_storage.save(stored_path)

    return safe_name, stored_name, stored_path


# ---------------------------------------------------------
# SESSION HELPERS
#
# Passwords are stored only as salted hashes produced by
# Werkzeug (pbkdf2 / scrypt). A plain password is never
# written anywhere, and no secret is ever sent to the
# frontend.
# ---------------------------------------------------------

def public_user(user):
    """The safe subset of a user that may be sent out."""

    return {
        "id": user["id"],
        "name": user["name"],
        "email": user["email"],
        "created_at": user.get("created_at"),
    }


def current_user():
    """Return the signed-in user, or None."""

    user_id = session.get("user_id")

    if not user_id:
        return None

    user = database.get_user_by_id(user_id)

    if user is None:
        return None

    # Flask's session cookie is signed, not encrypted, and lives on
    # the client. Clearing it on logout only asks the browser to
    # replace it, so a copy taken beforehand would otherwise keep
    # working until it expired. Comparing the version stored in the
    # cookie against the account's current one makes signing out
    # genuinely revoke every session issued before it.
    cookie_version = session.get("session_version")

    if cookie_version is None:
        # A session issued before this feature existed carries no
        # version. Accept it only while the account is still on the
        # initial version, so the next logout locks it out.
        if database.get_session_version(user_id) != 0:
            return None
    elif cookie_version != database.get_session_version(user_id):
        return None

    return user


def require_auth(view):
    """
    Reject the request with 401 unless a valid session cookie
    is present. Being logged out is never a server error.
    """

    @wraps(view)
    def wrapper(*args, **kwargs):

        user = current_user()

        if not user:
            return jsonify({
                "error": "Please log in to continue.",
                "auth_required": True,
            }), 401

        # Passed by keyword so it can never collide with a
        # path parameter such as analysis_id.
        kwargs["user"] = user

        return view(*args, **kwargs)

    return wrapper


# ---------------------------------------------------------
# HEALTH / BANNER
# ---------------------------------------------------------

@app.route("/", methods=["GET"])
def home():
    return jsonify({
        "message": "ResumeAI AI service is running",
        "status": "online",
    })


@app.route("/health", methods=["GET"])
def health():
    db_state = database.health()

    gemini_configured = False

    try:
        import analyzer
        gemini_configured = bool(analyzer.GEMINI_IS_CONFIGURED)
    except Exception:  # noqa: BLE001
        pass

    return jsonify({
        "status": "ok",
        "service": "resumeai-ai-service",
        "database": db_state,
        "gemini_enabled": gemini_configured,
        "max_upload_bytes": app.config["MAX_CONTENT_LENGTH"],
    }), (200 if db_state.get("database") == "ok" else 503)


# ---------------------------------------------------------
# CAREER PROFILE
#
# Every route is ownership scoped: the user id comes from the
# session cookie, and each query filters on it. No id in the
# URL or body is ever trusted for authorisation.
# ---------------------------------------------------------

@app.route("/career-profile", methods=["GET"])
@require_auth
def career_profile_get(user):
    """The whole profile: details plus every entry."""

    try:
        return jsonify(
            career_profile.get_workspace(user["id"])
        ), 200

    except Exception as error:

        print("Career profile read error:", str(error))

        return jsonify({
            "error": "Could not load your career profile."
        }), 500


@app.route("/career-profile", methods=["PUT"])
@require_auth
def career_profile_update(user):
    """Create or update the signed-in user's own details."""

    payload = request.get_json(silent=True) or {}

    if not isinstance(payload, dict):
        return jsonify({
            "error": "A JSON object is required."
        }), 400

    try:
        saved = career_profile.upsert_profile(
            user["id"], payload
        )

        if saved is None:
            return jsonify({
                "error": "Could not save your career profile."
            }), 500

        return jsonify({
            "message": "Career profile saved.",
            "profile": career_profile.profile_to_dict(saved),
        }), 200

    except Exception as error:

        print("Career profile save error:", str(error))

        return jsonify({
            "error": "Could not save your career profile."
        }), 500


@app.route("/career-profile/items", methods=["POST"])
@require_auth
def career_profile_add_item(user):
    """Add one education / project / experience entry."""

    payload = request.get_json(silent=True) or {}

    if not isinstance(payload, dict):
        return jsonify({
            "error": "A JSON object is required."
        }), 400

    created, error = career_profile.add_item(
        user["id"], payload
    )

    if error:
        return jsonify({"error": error}), 400

    return jsonify({
        "message": "Entry added.",
        "item": created,
    }), 201


@app.route("/career-profile/items/<int:item_id>",
           methods=["PUT", "PATCH"])
@require_auth
def career_profile_edit_item(user, item_id):
    """Update one entry the signed-in user owns."""

    payload = request.get_json(silent=True) or {}

    if not isinstance(payload, dict):
        return jsonify({
            "error": "A JSON object is required."
        }), 400

    updated, error = career_profile.update_item(
        user["id"], item_id, payload
    )

    if error == "not found":
        # Another account's entry is reported exactly like a
        # missing one, so ids cannot be probed.
        return jsonify({"error": "Entry not found."}), 404

    if error:
        return jsonify({"error": error}), 400

    return jsonify({
        "message": "Entry updated.",
        "item": updated,
    }), 200


@app.route("/career-profile/items/<int:item_id>",
           methods=["DELETE"])
@require_auth
def career_profile_remove_item(user, item_id):
    """Delete one entry the signed-in user owns."""

    removed = career_profile.delete_item(
        user["id"], item_id
    )

    if not removed:
        return jsonify({"error": "Entry not found."}), 404

    return jsonify({
        "message": "Entry deleted.",
        "id": item_id,
    }), 200


# ---------------------------------------------------------
# CAREER MISSION
#
# A mission belongs to exactly one account. The user id always
# comes from the session cookie, and every query filters on it,
# so an id in a URL can never reach another account's plan.
# ---------------------------------------------------------


@app.route("/missions", methods=["GET"])
@require_auth
def missions_list(user):
    """Every mission the signed-in user owns."""

    try:
        return jsonify({
            "missions": mission.list_missions(user["id"])
        }), 200

    except Exception as error:

        print("Mission list error:", str(error))

        return jsonify({
            "error": "Could not load your Career Missions."
        }), 500


@app.route("/missions/preview", methods=["POST"])
@require_auth
def mission_preview(user):
    """
    Build a plan without saving anything.

    Lets the page show exactly what will be created, including the
    gaps behind it, before the user commits.
    """

    payload = request.get_json(silent=True) or {}

    plan = mission.build_plan(user["id"], payload.get("role_key"))

    if plan is None:
        return jsonify({
            "error": "Choose a valid target role."
        }), 400

    return jsonify({
        "assessment": plan["assessment"],
        "task_count": len(plan["tasks"]),
        "tasks": plan["tasks"],
    }), 200


@app.route("/missions", methods=["POST"])
@require_auth
def mission_create(user):
    """
    Create or refresh the user's mission for a role.

    Refreshing keeps the progress already made: tasks are matched
    by key, so completed work is never thrown away.
    """

    payload = request.get_json(silent=True) or {}

    role_key = payload.get("role_key")

    if not role_key:
        return jsonify({
            "error": "Choose a target role first."
        }), 400

    plan = mission.build_plan(user["id"], role_key)

    if plan is None:
        return jsonify({
            "error": "Choose a valid target role."
        }), 400

    saved, error = mission.save_mission(
        user["id"],
        role_key,
        plan["tasks"],
        plan["assessment"],
        job_title=payload.get("job_title"),
        job_reference=payload.get("job_reference"),
    )

    if error:
        return jsonify({"error": error}), 400

    return jsonify({
        "message": "Career Mission created.",
        "mission": saved,
    }), 201


@app.route("/missions/<int:mission_id>", methods=["GET"])
@require_auth
def mission_get(user, mission_id):
    """One mission with its tasks, progress and next action."""

    try:
        found = mission.get_mission(user["id"], mission_id)

        if found is None:
            return jsonify({"error": "Mission not found."}), 404

        return jsonify({"mission": found}), 200

    except Exception as error:

        print("Mission read error:", str(error))

        return jsonify({
            "error": "Could not load this Career Mission."
        }), 500


@app.route("/missions/<int:mission_id>", methods=["DELETE"])
@require_auth
def mission_delete(user, mission_id):
    """Delete a mission and its tasks."""

    removed = mission.delete_mission(user["id"], mission_id)

    if not removed:
        return jsonify({"error": "Mission not found."}), 404

    return jsonify({
        "message": "Mission deleted.",
        "id": mission_id,
    }), 200


@app.route("/missions/tasks/<int:task_id>", methods=["PUT"])
@require_auth
def mission_task_update(user, task_id):
    """
    Set a task to not_started, in_progress or completed.

    The status is validated here, and ownership is enforced in the
    UPDATE itself.
    """

    payload = request.get_json(silent=True) or {}

    updated, error = mission.set_task_status(
        user["id"], task_id, payload.get("status")
    )

    if error == "Task not found.":
        return jsonify({"error": error}), 404

    if error:
        return jsonify({"error": error}), 400

    return jsonify({
        "message": "Task updated.",
        "task": updated,
    }), 200


# ---------------------------------------------------------
# JOB DISCOVERY
#
# With no provider configured this returns real search links, not
# listings, and says so in the payload. Nothing is fabricated.
# ---------------------------------------------------------


@app.route("/jobs/search", methods=["POST"])
@require_auth
def job_search(user):
    """Search. Returns live listings only when a provider answers."""

    payload = request.get_json(silent=True) or {}

    if not isinstance(payload, dict):
        payload = {}

    try:
        filters = jobs.clean_filters(payload)
        result = jobs.search(filters)

        # The filters that were actually applied, after cleaning and
        # fallback. The page shows these back to the user, so an
        # unrecognised value is visibly corrected rather than
        # silently ignored.
        result["filters"] = filters

        return jsonify(result), 200

    except Exception as error:

        print("Job search error:", type(error).__name__, str(error))

        return jsonify({
            "mode": "external",
            "listings": [],
            "links": [],
            "count": 0,
            "notice": (
                "Job search is temporarily unavailable. Nothing has "
                "been invented in its place."
            ),
        }), 503


@app.route("/jobs/meta", methods=["GET"])
@require_auth
def job_meta(user):
    """Filters, cities and which providers are configured."""

    return jsonify(jobs.search_meta()), 200


@app.route("/saved-jobs", methods=["GET"])
@require_auth
def saved_jobs_list(user):
    return jsonify({"jobs": jobs.list_jobs(user["id"])}), 200


@app.route("/saved-jobs", methods=["POST"])
@require_auth
def saved_job_create(user):
    """Save a job the user found on a real site."""

    payload = request.get_json(silent=True) or {}

    created, error = jobs.save_job(user["id"], payload)

    if error:
        return jsonify({"error": error}), 400

    return jsonify({
        "message": "Job saved.",
        "job": created,
    }), 201


@app.route("/saved-jobs/<int:job_id>", methods=["PUT", "PATCH"])
@require_auth
def saved_job_update(user, job_id):
    payload = request.get_json(silent=True) or {}

    updated, error = jobs.update_job(user["id"], job_id, payload)

    if error == "Job not found.":
        return jsonify({"error": error}), 404

    if error:
        return jsonify({"error": error}), 400

    return jsonify({"message": "Job updated.", "job": updated}), 200


@app.route("/saved-jobs/<int:job_id>", methods=["DELETE"])
@require_auth
def saved_job_delete(user, job_id):
    if not jobs.delete_job(user["id"], job_id):
        return jsonify({"error": "Job not found."}), 404

    return jsonify({"message": "Job deleted.", "id": job_id}), 200


# ---------------------------------------------------------
# SKILL PASSPORT
# ---------------------------------------------------------

@app.route("/skill-passport", methods=["GET"])
@require_auth
def skill_passport(user):
    """Evidence entries plus the skill map behind them."""

    try:
        return jsonify({
            "entries": passport.list_entries(user["id"]),
            "skills": passport.skill_map(user["id"]),
            "kinds": list(passport.KINDS),
        }), 200

    except Exception as error:

        print("Skill passport error:", type(error).__name__, str(error))

        return jsonify({
            "error": "Could not load your Skill Passport."
        }), 500


@app.route("/skill-passport", methods=["POST"])
@require_auth
def skill_passport_add(user):
    """Record a project, repository, certificate or exercise."""

    payload = request.get_json(silent=True) or {}

    created, error = passport.add_entry(user["id"], payload)

    if error:
        return jsonify({"error": error}), 400

    return jsonify({
        "message": "Evidence added.",
        "entry": created,
        "skills": passport.skill_map(user["id"]),
    }), 201


@app.route("/skill-passport/<int:entry_id>",
           methods=["PUT", "PATCH"])
@require_auth
def skill_passport_update(user, entry_id):
    payload = request.get_json(silent=True) or {}

    updated, error = passport.update_entry(
        user["id"], entry_id, payload
    )

    if error == "Entry not found.":
        return jsonify({"error": error}), 404

    if error:
        return jsonify({"error": error}), 400

    return jsonify({
        "message": "Evidence updated.",
        "entry": updated,
        "skills": passport.skill_map(user["id"]),
    }), 200


@app.route("/skill-passport/<int:entry_id>",
           methods=["DELETE"])
@require_auth
def skill_passport_delete(user, entry_id):
    if not passport.delete_entry(user["id"], entry_id):
        return jsonify({"error": "Entry not found."}), 404

    return jsonify({
        "message": "Evidence deleted.",
        "skills": passport.skill_map(user["id"]),
    }), 200


@app.route("/skill-passport/bullets", methods=["POST"])
@require_auth
def skill_passport_bullets(user):
    """
    Turn recorded work into editable bullet wording.

    Read only, and deliberately worded as prompts rather than
    finished claims, so nothing joins a resume without the user
    deciding it belongs there.
    """

    payload = request.get_json(silent=True) or {}

    return jsonify({
        "suggestions": passport.bullet_suggestions(
            user["id"], payload.get("entry_id")
        ),
        "disclaimer": (
            "Built from what you wrote. These are starting points "
            "for you to edit, and nothing has been added to any "
            "resume."
        ),
    }), 200


# ---------------------------------------------------------
# APPLICATION TRACKER
# ---------------------------------------------------------

@app.route("/applications", methods=["GET"])
@require_auth
def applications_list(user):
    return jsonify({
        "applications": tracker.list_all(user["id"]),
        "summary": tracker.summary(user["id"]),
        "statuses": [
            {"key": key, "label": tracker.STATUS_LABELS[key]}
            for key in tracker.STATUSES
        ],
    }), 200


@app.route("/applications", methods=["POST"])
@require_auth
def application_create(user):
    """Start tracking an application. Notes stay private."""

    payload = request.get_json(silent=True) or {}

    created, error = tracker.create(user["id"], payload)

    if error:
        return jsonify({"error": error}), 400

    return jsonify({
        "message": "Application saved.",
        "application": created,
        "summary": tracker.summary(user["id"]),
    }), 201


@app.route("/applications/<int:application_id>",
           methods=["PUT", "PATCH"])
@require_auth
def application_update(user, application_id):
    """Change status, dates or notes. Status changes are logged."""

    payload = request.get_json(silent=True) or {}

    updated, error = tracker.update(
        user["id"], application_id, payload
    )

    if error == "Application not found.":
        return jsonify({"error": error}), 404

    if error:
        return jsonify({"error": error}), 400

    return jsonify({
        "message": "Application updated.",
        "application": updated,
        "summary": tracker.summary(user["id"]),
    }), 200


@app.route("/applications/<int:application_id>",
           methods=["DELETE"])
@require_auth
def application_delete(user, application_id):
    if not tracker.delete(user["id"], application_id):
        return jsonify({"error": "Application not found."}), 404

    return jsonify({
        "message": "Application deleted.",
        "summary": tracker.summary(user["id"]),
    }), 200


# ---------------------------------------------------------
# AI CAREER ASSISTANT
# ---------------------------------------------------------

@app.route("/assistant/status", methods=["GET"])
def assistant_status():
    """Whether the assistant is live. Never exposes a key."""

    return jsonify(career_ai.status()), 200


@app.route("/assistant/ask", methods=["POST"])
@require_auth
def assistant_ask(user):
    """
    Ask the assistant something.

    Nothing is written to the user's records. The answer comes back
    for them to read.
    """

    payload = request.get_json(silent=True) or {}

    if not isinstance(payload, dict):
        payload = {}

    kind = str(payload.get("kind") or "next_step")

    result, error = career_ai.ask(user["id"], kind, payload)

    if error:
        return jsonify({"error": error}), 400

    result["kind"] = kind

    return jsonify({
        "result": result,
        "ai": career_ai.status(),
    }), 200


# ---------------------------------------------------------
# RESUME TEMPLATES AND BUILDER
## Every route is ownership scoped: the user id comes from the
# session cookie and sits in the WHERE clause of each query.
# Built resumes live in saved_resumes, which is separate from
# the uploads table the analyser uses.
# ---------------------------------------------------------


@app.route("/resume-templates", methods=["GET"])
def resume_templates():
    """
    The template catalogue.

    Public on purpose: browsing designs needs no account, and no
    private data is involved. Only sample content is returned.

    Filtering, searching, sorting and paging all happen here so the
    count the gallery shows is the number of templates that actually
    match, and so a browser cannot get a different answer to the same
    question than another browser.
    """

    args = request.args

    # A page size with a ceiling: the payload carries a full sample
    # resume per template for the thumbnail, so an unbounded
    # response would be megabytes on one request.
    try:
        limit = int(args.get("limit", 24))
    except (TypeError, ValueError):
        limit = 24

    limit = max(1, min(limit, 60))

    try:
        offset = int(args.get("offset", 0))
    except (TypeError, ValueError):
        offset = 0

    ats_only = args.get("ats", "").lower() in ("1", "true", "yes")

    try:
        entries, total = templates.list_templates(
            category=args.get("category", ""),
            query=args.get("q", ""),
            ats_only=ats_only,
            experience=args.get("experience", ""),
            layout=args.get("layout", ""),
            columns=args.get("columns", ""),
            header=args.get("header", ""),
            section_style=args.get("section_style", ""),
            sort=args.get("sort", "featured"),
            offset=offset,
            limit=limit,
        )

        return jsonify({
            "templates": entries,
            "total": total,
            "offset": max(0, offset),
            "limit": limit,
            "has_more": max(0, offset) + len(entries) < total,
            "facets": templates.library_facets(),
            "categories": templates.list_categories(),
            "fonts": [
                {
                    "key": key,
                    "label": value["label"],
                    "ats_note": value["ats_note"],
                }
                for key, value in templates.FONT_SETS.items()
            ],
            "accents": templates.ACCENT_PRESETS,
            "sections": templates.editor_sections(),
            "disclaimer": (
                "ATS-friendly means the layout uses standard headings, "
                "a single reading order and selectable text. It is "
                "worked out from the layout's structure, not a "
                "marketing label. No template can guarantee how any "
                "employer's software will read your file."
            ),
        }), 200

    except Exception as error:

        # Printed loudly, not swallowed: a silent fallback here once
        # hid a catalogue that could not be built at all.
        print("Template catalogue error:", str(error))

        return jsonify({
            "error": "Could not load the template gallery."
        }), 500


@app.route("/my-resumes", methods=["GET"])
@require_auth
def my_resumes(user):
    """Every built resume the signed-in user owns."""

    try:
        return jsonify({
            "resumes": resume_builder.list_resumes(user["id"])
        }), 200

    except Exception as error:

        print("Resume list error:", str(error))

        return jsonify({
            "error": "Could not load your saved resumes."
        }), 500


@app.route("/my-resumes", methods=["POST"])
@require_auth
def create_my_resume(user):
    """
    Start a new resume.

    With no body it is seeded from the sample data so the gallery
    preview and the editor start from the same place. Passing
    start_empty creates a genuinely blank resume instead.
    """

    payload = request.get_json(silent=True) or {}

    if not isinstance(payload, dict):
        payload = {}

    start_empty = bool(payload.get("start_empty"))
    from_profile = bool(payload.get("from_profile"))

    try:
        created = resume_builder.create_resume(
            user["id"],
            title=payload.get("title"),
            template_key=payload.get("template_key"),
            # An empty dict, not None: None is the signal for "seed
            # from the sample", so passing it here would fill a
            # blank resume with the sample's details.
            content={} if start_empty else payload.get("content"),
            settings=payload.get("settings"),
            target_role=payload.get("target_role"),
            # Seeded from the user's own Career Profile. Everything in
            # it was typed by them; nothing is generated.
            from_profile=from_profile and not start_empty,
        )

        return jsonify({
            "message": "Resume created.",
            "resume": created,
        }), 201

    except Exception as error:

        print("Resume create error:", str(error))

        return jsonify({
            "error": "Could not create that resume."
        }), 500


@app.route("/my-resumes/<int:resume_id>", methods=["GET"])
@require_auth
def get_my_resume(user, resume_id):
    """One built resume in full."""

    try:
        found = resume_builder.get_resume(user["id"], resume_id)

        if found is None:
            return jsonify({"error": "Resume not found."}), 404

        return jsonify({"resume": found}), 200

    except Exception as error:

        print("Resume read error:", str(error))

        return jsonify({
            "error": "Could not load that resume."
        }), 500


@app.route("/my-resumes/<int:resume_id>", methods=["PUT", "PATCH"])
@require_auth
def update_my_resume(user, resume_id):
    """
    Save edits, rename, or switch template.

    Changing the template never touches the content, so a resume
    can be re-skinned without losing anything.
    """

    payload = request.get_json(silent=True) or {}

    if not isinstance(payload, dict):
        return jsonify({
            "error": "A JSON object is required."
        }), 400

    updated, error = resume_builder.update_resume(
        user["id"], resume_id, payload
    )

    if error == "Resume not found.":
        return jsonify({"error": error}), 404

    if error:
        return jsonify({"error": error}), 400

    return jsonify({
        "message": "Resume saved.",
        "resume": updated,
    }), 200


@app.route("/my-resumes/<int:resume_id>/duplicate", methods=["POST"])
@require_auth
def duplicate_my_resume(user, resume_id):
    """Copy a resume so the same content can target another role."""

    try:
        copy = resume_builder.duplicate_resume(user["id"], resume_id)

        if copy is None:
            return jsonify({"error": "Resume not found."}), 404

        return jsonify({
            "message": "Resume duplicated.",
            "resume": copy,
        }), 201

    except Exception as error:

        print("Resume duplicate error:", str(error))

        return jsonify({
            "error": "Could not duplicate that resume."
        }), 500


@app.route("/my-resumes/<int:resume_id>", methods=["DELETE"])
@require_auth
def delete_my_resume(user, resume_id):
    """Delete a resume the signed-in user owns."""

    removed = resume_builder.delete_resume(user["id"], resume_id)

    if not removed:
        return jsonify({"error": "Resume not found."}), 404

    return jsonify({
        "message": "Resume deleted.",
        "id": resume_id,
    }), 200


@app.route("/my-resumes/<int:resume_id>/pdf", methods=["GET"])
@require_auth
def export_my_resume_pdf(user, resume_id):
    """
    Render the resume to a real PDF.

    The text is written as PDF text, not as a picture, so the file
    can be selected, searched and read by an applicant tracking
    system. Filenames are built from the resume title with
    anything unsafe removed.
    """

    found = resume_builder.get_resume(user["id"], resume_id)

    if found is None:
        return jsonify({"error": "Resume not found."}), 404

    content = resume_builder.clean_content(found["content"])
    settings = resume_builder.clean_settings(
        found["settings"], found["template_key"]
    )

    try:
        pdf = resume_pdf.build_pdf(
            content, found["template_key"], settings
        )

    except Exception as error:

        print("PDF export failed:", type(error).__name__, str(error))

        return jsonify({
            "error": (
                "The PDF could not be generated. Your resume is "
                "still saved, so nothing has been lost."
            )
        }), 500

    safe = secure_filename(found["title"] or "resume") or "resume"

    response = app.response_class(pdf, mimetype="application/pdf")
    response.headers["Content-Disposition"] = (
        f'attachment; filename="{safe}.pdf"'
    )
    response.headers["Content-Length"] = str(len(pdf))
    response.headers["X-Content-Type-Options"] = "nosniff"

    return response


@app.route("/my-resumes/<int:resume_id>/suggest", methods=["POST"])
@require_auth
def suggest_resume(user, resume_id):
    """
    Writing suggestions for one part of a resume.

    Read only. Nothing is written back: the user sees the
    suggestions and decides what to apply, then saves normally.
    """

    found = resume_builder.get_resume(user["id"], resume_id)

    if found is None:
        return jsonify({"error": "Resume not found."}), 404

    payload = request.get_json(silent=True) or {}

    if not isinstance(payload, dict):
        payload = {}

    kind = str(payload.get("kind") or "sections")

    result, error = resume_ai.suggest(
        user["id"],
        found["content"],
        kind,
        payload.get("target_role") or found.get("target_role") or "",
    )

    if error:
        return jsonify({"error": error}), 400

    return jsonify({
        "kind": kind,
        "result": result,
        "ai": resume_ai.status(),
    }), 200


@app.route("/ai-status", methods=["GET"])
def ai_status():
    """Whether writing assistance is live. Never exposes the key."""

    return jsonify(resume_ai.status()), 200


# ---------------------------------------------------------
# RESUME ANALYSIS
# ---------------------------------------------------------

@app.route("/roles", methods=["GET"])
def roles():
    """Catalogue of selectable target roles."""

    return jsonify({
        "roles": list_roles()
    }), 200


@app.route("/analyze", methods=["POST"])
@require_auth
def analyze(user):

    # Check that a file was actually uploaded
    if "resume" not in request.files:
        return jsonify({
            "error": "No resume uploaded."
        }), 400

    file = request.files["resume"]

    if not file.filename:
        return jsonify({
            "error": "No file selected."
        }), 400

    # Only allow PDF files
    original_name = file.filename
    filename = original_name.lower()

    if os.path.splitext(filename)[1] not in ALLOWED_EXTENSIONS:
        return jsonify({
            "error": "Only PDF resume files are supported."
        }), 400

    temp_path = None
    stored_path = None

    try:

        # -------------------------------------------------
        # VALIDATE + STORE THE UPLOAD
        # -------------------------------------------------

        file.stream.seek(0)
        head = file.stream.read(5)

        if not looks_like_pdf(head):
            return jsonify({
                "error": (
                    "That file is not a valid PDF. "
                    "Please upload a real PDF resume."
                )
            }), 400

        file.stream.seek(0)

        # A proxy may forward the readable name for history. It
        # is sanitised again, and the on-disk name stays random.
        display_name = (
            request.form.get("original_filename")
            or original_name
        )

        safe_name, stored_name, stored_path = save_upload(
            file, display_name
        )

        file_size = os.path.getsize(stored_path)

        # -------------------------------------------------
        # EXTRACT TEXT
        # Text PDFs are read directly; scanned PDFs are OCR'd.
        # -------------------------------------------------

        extraction = extract_text_detailed(stored_path)

        text = extraction["text"]

        print(
            f"Extraction method: {extraction['method'] or 'none'} "
            f"| pages: {extraction['pages']} "
            f"| chars: {len(text)} "
            f"| reason: {extraction['reason'] or 'none'}"
        )

        if not text or not text.strip():

            _safe_remove(stored_path)

            return jsonify({
                "error": friendly_error(extraction["reason"]),
                "extraction": {
                    "reason": extraction["reason"] or "no_text",
                    "method": extraction["method"],
                    "pages": extraction["pages"],
                },
            }), 422

        # -------------------------------------------------
        # ANALYZE RESUME
        # Optional job_description is used by the ATS criterion
        # (jd_comparison + missing-keyword actions). Scoring still
        # works the same when it is omitted.
        # -------------------------------------------------

        job_description = (
            request.form.get("job_description")
            or request.form.get("jobDescription")
            or ""
        )
        if not isinstance(job_description, str):
            job_description = ""
        job_description = job_description.strip()[:20000]

        # Optional target role, used for role matching and the
        # recommended / missing skill list.
        target_role = (
            request.form.get("target_role")
            or request.form.get("targetRole")
            or ""
        )
        if not isinstance(target_role, str):
            target_role = ""
        target_role = target_role.strip()[:80]

        result = analyze_resume(
            text,
            job_description=job_description,
            target_role=target_role
        )

        # -------------------------------------------------
        # STORE THE ANALYSIS
        # A storage failure must not lose a good analysis.
        # -------------------------------------------------

        analysis_id = None
        database_error = None

        try:
            resume_id = database.save_resume(
                user["id"],
                safe_name,
                stored_name,
                file_size,
                text
            )

            analysis_id = database.save_analysis(
                resume_id,
                user["id"],
                result,
                job_description
            )

        except Exception as storage_error:  # noqa: BLE001
            database_error = str(storage_error)
            print("Could not store analysis:", storage_error)

        if analysis_id is not None:
            result["analysis_id"] = analysis_id
        else:
            result["database_saved"] = False

        if database_error:
            result["database_error"] = database_error

        # -------------------------------------------------
        # RETURN RESULT
        # -------------------------------------------------

        return jsonify(result), 200

    except Exception as error:

        print(
            "Resume analysis error:",
            str(error)
        )

        _safe_remove(stored_path)

        return jsonify({
            "error": (
                "An unexpected error occurred "
                "while analyzing the resume."
            )
        }), 500

    finally:

        # -------------------------------------------------
        # DELETE TEMPORARY FILE
        # -------------------------------------------------

        if temp_path and os.path.exists(temp_path):
            _safe_remove(temp_path)


# ---------------------------------------------------------
# ANALYSIS HISTORY
# ---------------------------------------------------------

@app.route("/analyses", methods=["GET"])
@require_auth
def analyses(user):
    try:
        limit = request.args.get("limit", 50, type=int)
        offset = request.args.get("offset", 0, type=int)

        items, total = database.list_analyses(
            user["id"], limit, offset
        )

        return jsonify({
            "analyses": items,
            "count": len(items),
            "total": total,
            "limit": limit,
            "offset": offset,
        }), 200

    except Exception as error:

        print("List analyses error:", str(error))

        return jsonify({
            "error": "Could not load analysis history."
        }), 500


@app.route("/analyses/<int:analysis_id>", methods=["GET"])
@require_auth
def analysis_detail(analysis_id, user):
    try:
        record = database.get_analysis(
            analysis_id, user_id=user["id"]
        )

        if not record:
            return jsonify({
                "error": "Analysis not found."
            }), 404

        return jsonify(record), 200

    except Exception as error:

        print("Analysis detail error:", str(error))

        return jsonify({
            "error": "Could not load this analysis."
        }), 500


@app.route("/analyses/<int:analysis_id>", methods=["DELETE"])
@require_auth
def analysis_delete(analysis_id, user):
    try:
        removed = database.delete_analysis(
            analysis_id, user_id=user["id"]
        )

        if not removed:
            return jsonify({
                "error": "Analysis not found."
            }), 404

        return jsonify({
            "deleted": True,
            "id": analysis_id
        }), 200

    except Exception as error:

        print("Delete analysis error:", str(error))

        return jsonify({
            "error": "Could not delete this analysis."
        }), 500


# ---------------------------------------------------------
# ERROR HANDLERS
# ---------------------------------------------------------

@app.errorhandler(413)
def file_too_large(error):
    return jsonify({
        "error": "Resume file is too large. Maximum size is 5MB."
    }), 413


@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "error": "Endpoint not found."
    }), 404


@app.errorhandler(500)
def server_error(error):
    return jsonify({
        "error": "Internal server error."
    }), 500


def _safe_remove(path):
    """Remove a file without ever raising."""

    if path and os.path.exists(path):
        try:
            os.remove(path)
        except OSError as cleanup_error:
            print(
                "File cleanup failed:",
                str(cleanup_error)
            )


# ---------------------------------------------------------
# AUTHENTICATION ROUTES
# ---------------------------------------------------------

@app.route("/auth/register", methods=["POST"])
def register():
    """Create an account and sign the user in."""

    payload = request.get_json(silent=True) or {}

    name = str(payload.get("name") or "").strip()
    email = str(payload.get("email") or "").strip()
    password = str(payload.get("password") or "")

    if not name:
        return jsonify({
            "error": "Please enter your name."
        }), 400

    if not _is_valid_email(email):
        return jsonify({
            "error": "Please enter a valid email address."
        }), 400

    if len(password) < MIN_PASSWORD_LENGTH:
        return jsonify({
            "error": (
                f"Password must be at least "
                f"{MIN_PASSWORD_LENGTH} characters."
            )
        }), 400

    try:
        user = database.create_user(
            name,
            email,
            generate_password_hash(password)
        )

    except ValueError as error:
        return jsonify({
            "error": str(error)
        }), 409

    except Exception as error:

        print("Registration error:", str(error))

        return jsonify({
            "error": "Could not create the account."
        }), 500

    session.clear()
    session["user_id"] = user["id"]
    # Stamped so logout can revoke this cookie server-side.
    session["session_version"] = database.get_session_version(user["id"])
    session.permanent = True

    return jsonify({
        "message": "Account created.",
        "user": public_user(user),
    }), 201


@app.route("/auth/login", methods=["POST"])
def login():
    """Verify the password and start a session."""

    payload = request.get_json(silent=True) or {}

    email = str(payload.get("email") or "").strip()
    password = str(payload.get("password") or "")

    if not email or not password:
        return jsonify({
            "error": "Please enter your email and password."
        }), 400

    user = database.get_user_by_email(email)

    # The same message for an unknown email and a wrong
    # password, so the form cannot be used to probe accounts.
    invalid = {
        "error": "Incorrect email or password."
    }

    if not user:
        return jsonify(invalid), 401

    stored_hash = user.get("password_hash")

    # Accounts created before logins existed have no password
    # and must not be signable.
    if not stored_hash:
        return jsonify(invalid), 401

    try:
        password_ok = check_password_hash(
            stored_hash, password
        )
    except (ValueError, TypeError):
        password_ok = False

    if not password_ok:
        return jsonify(invalid), 401

    session.clear()
    session["user_id"] = user["id"]
    # Stamped so logout can revoke this cookie server-side.
    session["session_version"] = database.get_session_version(user["id"])
    session.permanent = True

    return jsonify({
        "message": "Logged in.",
        "user": public_user(user),
    }), 200


@app.route("/auth/logout", methods=["POST"])
def logout():
    """
    Sign out, and actually revoke the session.

    Clearing the cookie is not enough on its own. Flask's session is
    a client-side signed cookie, so any copy captured before this
    call would still verify. Bumping the account's session version
    is what makes those copies stop working.
    """

    user_id = session.get("user_id")

    if user_id:
        database.bump_session_version(user_id)

    session.clear()

    return jsonify({
        "message": "Logged out."
    }), 200


@app.route("/auth/me", methods=["GET"])
def auth_me():
    """Who am I? Used by the frontend to protect routes."""

    user = current_user()

    if not user:
        return jsonify({
            "authenticated": False,
            "user": None,
        }), 200

    return jsonify({
        "authenticated": True,
        "user": public_user(user),
        # Told to the client so the browser can end its own session
        # after this much inactivity. Without it the two sides can
        # disagree: the server refreshing a cookie on every request
        # would keep a session alive that the user expects to have
        # ended.
        "idle_minutes": app.config["RESUMEAI_IDLE_MINUTES"],
    }), 200


# ---------------------------------------------------------
# DATABASE BOOTSTRAP
#
# This runs on import, not under __main__, so the schema is
# correct however the service was started: `python app.py`,
# `flask run`, gunicorn or waitress all import this module.
# A backup is written automatically before a migration changes
# anything. Both calls are idempotent.
# ---------------------------------------------------------

try:
    database.init_db()
    migrations.run()

except Exception as error:  # noqa: BLE001
    # A locked or unreadable database (for example OneDrive
    # holding the file) must not stop the process from starting.
    # Say so loudly: requests that need the new tables will fail
    # with a clear error instead of silently returning bad data.
    print()
    print("!" * 68)
    print("DATABASE MIGRATION FAILED:", error)
    print("The service started, but features needing the new schema")
    print("will error until this is fixed. Stop any other process")
    print("using the database and restart.")
    print("!" * 68)
    print()


# ---------------------------------------------------------
# START SERVER
# ---------------------------------------------------------

if __name__ == "__main__":

    app.run(
        host="127.0.0.1",
        port=8000,
        debug=True
    )
