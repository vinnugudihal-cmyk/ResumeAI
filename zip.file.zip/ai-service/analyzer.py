import os
import sys

from google import genai
from dotenv import load_dotenv

from skills import find_skills
from scorer import evaluate_resume_criteria
from roles import evaluate_role


# ============================================================
# CONSOLE OUTPUT SAFETY
#
# The debug logging below prints resume text, which can hold
# characters that the Windows console codepage (cp1252) cannot
# encode. An unprintable character used to raise a
# UnicodeEncodeError that was reported to the browser as a
# 500 error. Streams are switched to UTF-8 with replacement so
# logging can never fail the analysis.
# ============================================================

for _stream in (sys.stdout, sys.stderr):

    try:
        _stream.reconfigure(
            encoding="utf-8",
            errors="replace"
        )

    except Exception:
        pass


# ============================================================
# LOAD ENVIRONMENT VARIABLES
# ============================================================

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

# Ignore the untouched .env placeholder so the service does not
# call Gemini with a fake key on every single upload.
PLACEHOLDER_KEYS = {
    "",
    "paste_your_api_key_here",
    "your_api_key",
    "your-api-key",
    "changeme",
}

GEMINI_IS_CONFIGURED = bool(
    GEMINI_API_KEY
    and GEMINI_API_KEY.strip().lower()
    not in PLACEHOLDER_KEYS
)

# Gemini is optional.
# The resume scoring engine will still work if the API key is missing.
client = (
    genai.Client(api_key=GEMINI_API_KEY)
    if GEMINI_IS_CONFIGURED
    else None
)


# ============================================================
# MAIN RESUME ANALYSIS FUNCTION
# ============================================================

def analyze_resume(text, job_description="", target_role=""):
    """
    Main ResumeAI analysis function.

    Flow:
        Resume text
            ↓
        Skill extraction
            ↓
        Explainable scoring engine
            ↓
        Gemini personalized suggestions
            ↓
        Complete analysis result
    """

    # --------------------------------------------------------
    # STEP 0: EMPTY / INVALID RESUME
    # --------------------------------------------------------

    if not text or not text.strip():
        return {
            "score": 0,
            "ats_score": 0,
            "skills": [],
            "suggestions": [
                "We could not extract meaningful text from this resume."
            ],
            "weaknesses": [],
            "missing_sections": [],
            "matched_keywords": [],
            "missing_keywords": [],
            "role_match": None,
            "ats_breakdown": None,
            "criteria": {},
            "improvement_plan": [],
            "breakdown": {
                "content": 0,
                "formatting": 0,
                "keywords": 0,
            },
        }

    # --------------------------------------------------------
    # STEP 1: EXTRACT TECHNICAL SKILLS
    # --------------------------------------------------------

    skills = find_skills(text)

    print("========== RESUME DEBUG ==========")

    print("EXTRACTED TEXT (first 2000 chars):")
    print(text[:2000])

    print("DETECTED SKILLS:")
    print(skills)

    print("JOB DESCRIPTION:")
    if job_description:
        if len(job_description) > 300:
            print(job_description[:300] + "...")
        else:
            print(job_description)
    else:
        print("(none)")

    print("==================================")


    # --------------------------------------------------------
    # STEP 2: RUN EXPLAINABLE SCORING ENGINE
    # --------------------------------------------------------

    result = evaluate_resume_criteria(
        text,
        skills,
        job_description
    )

    total_score = result["total_score"]

    criteria = result["criteria"]

    missing = result["missing_sections"]

    weaknesses = result["weaknesses"]

    suggestions = result["suggestions"]

    matched_kw = result.get(
        "matched_keywords",
        []
    )

    improvement_plan = result.get(
        "improvement_plan",
        []
    )

    # --------------------------------------------------------
    # STEP 1b. MISSING KEYWORDS
    #
    # Keywords the job description asks for that the resume
    # does not contain. Empty when no job description was
    # supplied, so the field is always safe for the frontend.
    # --------------------------------------------------------

    missing_kw = list(
        criteria["ats_keywords"]
        .get("jd_comparison", {})
        .get("missing_from_resume", [])
    )

    # --------------------------------------------------------
    # STEP 1d. TARGET ROLE MATCH
    #
    # Optional. Only skills genuinely detected in the resume are
    # ever reported as matched.
    # --------------------------------------------------------

    role_match = evaluate_role(skills, text, target_role)


    # --------------------------------------------------------
    # STEP 3: GEMINI PERSONALIZED SUGGESTIONS
    # --------------------------------------------------------

    gemini_suggestions = []

    if client:

        try:

            gemini_response = client.models.generate_content(
                model="gemini-2.5-flash",
                contents=f"""
You are a professional resume improvement assistant.

Analyze the following resume.

RESUME:
{text}

JOB DESCRIPTION:
{job_description or "No job description provided."}

Give exactly 3 concise and practical improvement suggestions.

Focus on:

1. Weak or missing skills
2. Resume wording and impact
3. Relevance to the job description

Return only a numbered list.

Do not give an overall score.
"""
            )

            if gemini_response.text:

                gemini_suggestions = [
                    line.strip()
                    for line in gemini_response.text.splitlines()
                    if line.strip()
                ]

        except Exception as error:

            print(
                "Gemini analysis failed:",
                error
            )

            gemini_suggestions = []

    else:

        print(
            "Gemini API key not configured. "
            "Skipping Gemini suggestions."
        )


    # --------------------------------------------------------
    # STEP 4: COMBINE SUGGESTIONS
    # --------------------------------------------------------

    final_suggestions = (
        suggestions +
        gemini_suggestions
    )


    # --------------------------------------------------------
    # STEP 5: DEBUG SCORING INFORMATION
    # --------------------------------------------------------

    print("CRITERIA SCORES:")

    for key, val in criteria.items():

        print(
            f"  [{val['label']}] "
            f"{val['score']}/{val['max_score']} — "
            f"{val['feedback']}"
        )

        if val.get("deductions"):

            for deduction in val["deductions"]:

                print(
                    f"    -> -{deduction['points']} pts: "
                    f"{deduction['reason']}"
                )

    print(
        f"TOTAL SCORE: {total_score}"
    )

    print(
        "GEMINI SUGGESTIONS:",
        gemini_suggestions
    )

    print(
        "=================================="
    )


    # --------------------------------------------------------
    # STEP 6: DERIVE LEGACY DASHBOARD BREAKDOWN
    # --------------------------------------------------------

    content_score = (
        criteria["structure"]["score"]
        + criteria["experience_projects"]["score"]
    )

    content_pct = round(
        (content_score / 40) * 100
    )

    keyword_score = (
        criteria["ats_keywords"]["score"]
    )

    keyword_pct = round(
        (keyword_score / 20) * 100
    )

    formatting_score = (
        criteria["formatting"]["score"]
    )

    formatting_pct = round(
        (formatting_score / 10) * 100
    )


    # --------------------------------------------------------
    # ATS COMPOSITE SCORE
    #
    # Keywords  = 40%
    # Skills    = 30%
    # Formatting = 30%
    # --------------------------------------------------------

    # This is a readability and keyword estimate produced by a
    # fixed, transparent rule set. It is not a guarantee of being
    # shortlisted or interviewed, and no automated score can be.
    # The components are returned so the number can be explained
    # rather than taken on trust.
    skills_pct = round(
        criteria["skills"]["score"] / 20 * 100
    )

    ats_components = {
        "keywords": {
            "label": "Keyword coverage",
            "score": keyword_score,
            "max_score": 20,
            "percent": keyword_pct,
            "weight": 0.40,
        },
        "skills": {
            "label": "Skill breadth",
            "score": criteria["skills"]["score"],
            "max_score": 20,
            "percent": skills_pct,
            "weight": 0.30,
        },
        "formatting": {
            "label": "Formatting",
            "score": formatting_score,
            "max_score": 10,
            "percent": formatting_pct,
            "weight": 0.30,
        },
    }

    ats_score = round(
        (keyword_pct * 0.40)
        + (skills_pct * 0.30)
        + (formatting_pct * 0.30)
    )

    ats_breakdown = {
        "components": ats_components,
        "method": (
            "Weighted estimate of machine readability: "
            "keyword coverage (40%), skill breadth (30%) and "
            "formatting (30%)."
        ),
        "disclaimer": (
            "This is an estimate based on the text and structure "
            "of your resume. It cannot predict whether an employer "
            "will shortlist you or call you for an interview."
        ),
    }


    # --------------------------------------------------------
    # STEP 7: RETURN COMPLETE ANALYSIS
    # --------------------------------------------------------

    return {

        # Core fields used by Dashboard
        "score": total_score,

        "total_score": total_score,

        "ats_score": ats_score,

        "ats_breakdown": ats_breakdown,

        "skills": skills,

        "suggestions": final_suggestions,

        # Full diagnostic information
        "criteria": criteria,

        "weaknesses": weaknesses,

        "missing_sections": missing,

        "matched_keywords": matched_kw,

        "missing_keywords": missing_kw,

        "role_match": role_match,

        "improvement_plan": improvement_plan,


        # Legacy Dashboard fields
        "breakdown": {

            "content": min(
                content_pct,
                100
            ),

            "formatting": min(
                formatting_pct,
                100
            ),

            "keywords": min(
                keyword_pct,
                100
            ),
        },
    }


# ============================================================
# OPTIONAL SKILL SUGGESTION FORMATTER
# ============================================================

def _format_skill_suggestions(suggested_categories):
    """
    Format missing skill categories into
    a readable string.
    """

    parts = []

    for cat, items in suggested_categories.items():

        parts.append(
            f"{cat}: {', '.join(items[:3])}"
        )

    return "; ".join(parts[:3])