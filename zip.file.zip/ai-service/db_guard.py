"""
Keep test code away from the production database.

A test suite that imports `database` inherits its `DB_PATH`. If a
suite forgets to point `RESUMEAI_DB` at a temporary file, every
insert it makes lands in the real database - which is how 23
accounts, 48 resumes and 48 analyses went missing from this project
on 2026-10-11.

Relying on every suite remembering to set an environment variable is
the failure mode that caused this, so the default is reversed here:
`database` refuses to resolve to the production file when it is
being imported by a test, and a suite that wants the real one has to
say so out loud.

Two ways a process is treated as a test:

  * the script being run is named ``test_*.py`` - this is the case
    for ``python test_auth.py`` and for a suite run under pytest,
    whose argv[0] is pytest but whose importing module still lives
    in a file named ``test_*``; or
  * ``RESUMEAI_TESTING`` is set, which is how a suite run from
    inside another runner announces itself.

`RESUMEAI_ALLOW_PRODUCTION_DB=1` is the only way past, and it is
deliberately awkward: it is an exact string, it has to be set before
`database` is imported, and `refuses_production_path()` reports when
it was used so a caller can refuse to go along with it.
"""

import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# The file that holds the user's real data. Never, under any test.
PRODUCTION_DB = os.path.normcase(
    os.path.join(BASE_DIR, "resumeai.db")
)

OVERRIDE = "RESUMEAI_ALLOW_PRODUCTION_DB"

TESTING_FLAG = "RESUMEAI_TESTING"


class ProductionDatabaseError(RuntimeError):
    """
    A test tried to use the production database.

    Raised at import time, before any connection is opened, so
    nothing has been written by the time it is raised.
    """


def _normalise(path):
    """Compare paths the way the filesystem does on this platform."""

    try:
        return os.path.normcase(os.path.realpath(os.path.abspath(path)))
    except (OSError, ValueError):
        return os.path.normcase(os.path.abspath(str(path)))


def is_production_path(path):
    """True if `path` is the user's live database."""

    if not path:
        return False

    return _normalise(path) == PRODUCTION_DB


def run_as_test(argv=None):
    """
    Whether this process should be treated as test code.

    Looks at the script being run rather than only at argv, because
    a suite executed by a runner has the runner in argv[0].
    """

    if os.environ.get(TESTING_FLAG):
        return True

    argv = list(argv if argv is not None else sys.argv)

    # The script named on the command line.
    for argument in argv:
        base = os.path.basename(str(argument))

        if base.startswith("test_") and base.endswith(".py"):
            return True

    # Any module already imported whose file lives in a test_*.py.
    # Catches `pytest`, `unittest` and a suite imported by another.
    for module in list(sys.modules.values()):
        filename = getattr(module, "__file__", None)

        if not filename:
            continue

        base = os.path.basename(filename)

        if base.startswith("test_") and base.endswith(".py"):
            return True

    return False


def refuses_production_path(argv=None):
    """
    Check the configured path and raise if it is the live database.

    Called by `database` on import. Returns quietly when the process
    is not test code, or when the override was set deliberately.
    """

    if not run_as_test(argv):
        return False

    configured = os.environ.get("RESUMEAI_DB")

    if configured and not is_production_path(configured):
        return False

    # Reaching here means a test would write to the real database.
    if os.environ.get(OVERRIDE) == "1":
        return False

    raise ProductionDatabaseError(
        "Refusing to run: this is a test, and it would use the "
        "production database.\n"
        "\n"
        "  configured: %s\n"
        "\n"
        "Point it at a temporary file before importing anything that "
        "opens the database:\n"
        "\n"
        "    import os, tempfile\n"
        "    os.environ['RESUMEAI_DB'] = os.path.join(\n"
        "        tempfile.mkdtemp(), 'test.db')\n"
        "\n"
        "or call test_guard.use_temporary_database(), which does that "
        "and returns the path.\n"
        "\n"
        "If you genuinely mean to touch real user data, set %s=1 "
        "in the environment before the import, and do it by hand "
        "rather than from a test."
        % (configured or "(unset - defaults to resumeai.db)", OVERRIDE)
    )


def use_temporary_database(environ=None):
    """
    Point RESUMEAI_DB at a fresh temporary file and return its path.

    Call before importing anything that opens the database.
    """

    import tempfile

    environ = environ if environ is not None else os.environ

    if environ.get(OVERRIDE) == "1":
        raise ProductionDatabaseError(
            "%s=1 is set, so a test cannot redirect the database. "
            "Remove it before running tests." % OVERRIDE
        )

    directory = tempfile.mkdtemp(prefix="resumeai_test_")

    path = os.path.join(directory, "test.db")

    environ["RESUMEAI_DB"] = path
    environ["RESUMEAI_UPLOADS"] = os.path.join(directory, "uploads")
    environ[TESTING_FLAG] = "1"

    return path