/**
 * The dashboard you land on after signing in.
 *
 * A launcher, not a second home page: it says what the app can do,
 * and every card goes to the place that does it. The analysis panel
 * stays below it on the same route, so nothing that used to live at
 * /dashboard has moved.
 *
 * The order is deliberate and is the thing most dashboards get
 * wrong. Building a resume and having a resume read are the two
 * things people come here to do, so they are the two things given
 * full width. Everything else is a smaller, equal card underneath.
 * Flattening all nine into one grid made the page read as a wall
 * of identical blue tiles with no starting point.
 *
 * The icons are inline SVG rather than an icon font or a package.
 * Nine glyphs are not worth a dependency, and inline SVG inherits
 * currentColor, so a card in any state draws its own icon.
 */

import { useNavigate } from "react-router-dom";

import {
  FEATURES,
  FEATURE_BY_KEY,
  PRIMARY,
  destinationFor,
} from "../services/features";
import "./Landing.css";

const PATHS = {
  create: <path d="M12 5v14M5 12h14" />,
  analyse: (
    <>
      <path d="M5 3.5h9l5 5V20a1 1 0 01-1 1H5a1 1 0 01-1-1V4.5a1 1 0 011-1z" />
      <path d="M14 3.5V9h5" />
      <circle cx="11.5" cy="14" r="3" />
      <path d="M13.8 16.3L16 18.5" />
    </>
  ),
  jobs: (
    <>
      <rect x="3" y="7" width="18" height="13" rx="2.5" />
      <path d="M9 7V5.5A1.5 1.5 0 0110.5 4h3A1.5 1.5 0 0115 5.5V7" />
      <path d="M3 12h18" />
    </>
  ),
  mission: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="12" cy="12" r="0.7" fill="currentColor" />
    </>
  ),
  applications: (
    <>
      <rect x="4" y="3.5" width="16" height="17" rx="2.5" />
      <path d="M8.5 9.5h7M8.5 13h7M8.5 16.5h4" />
    </>
  ),
  match: (
    <>
      <path d="M4 6h6M4 12h4M4 18h6" />
      <circle cx="16" cy="15" r="4" />
      <path d="M19 18l2.5 2.5" />
    </>
  ),
  profile: (
    <>
      <circle cx="12" cy="8.5" r="4" />
      <path d="M4.5 20a7.5 7.5 0 0115 0" />
    </>
  ),
  skills: (
    <path d="M12 3.5l2.4 4.9 5.4.8-3.9 3.8.9 5.4-4.8-2.6-4.8 2.6.9-5.4L4.2 9.2l5.4-.8z" />
  ),
  saved: (
    <path d="M6.5 4h11a1 1 0 011 1v15.2a.6.6 0 01-.93.5L12 16.6l-5.57 4.1a.6.6 0 01-.93-.5V5a1 1 0 011-1z" />
  ),
};

function Icon({ name }) {
  return (
    <svg
      className="land-icon"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
    >
      {PATHS[name] || PATHS.create}
    </svg>
  );
}

export default function Landing() {
  const navigate = useNavigate();

  const go = (feature) => navigate(destinationFor(feature));

  // Pulled out of FEATURES so the two headline cards are not also
  // rendered in the grid below. One feature, one card, one place.
  const analyse = FEATURE_BY_KEY.resume_analysis;
  const rest = FEATURES.filter((feature) => feature.key !== "resume_analysis");

  return (
    <section className="land" aria-labelledby="land-heading">
      <header className="land-head">
        <h1 id="land-heading" className="land-title">
          How can I help you today?
        </h1>
        <p className="land-sub">
          Build your resume, discover opportunities, and take the next
          step in your career.
        </p>
      </header>

      {/*
        The two headline cards. Full width, stacked, and visually
        ranked: Create is the accent one, Analyse is the quieter
        sibling directly beneath it. Neither shares a row with the
        grid, so neither competes with it.
      */}
      <button
        type="button"
        className="land-hero land-hero-primary"
        onClick={() => go(PRIMARY)}
      >
        <span className="land-hero-icon" aria-hidden="true">
          <Icon name={PRIMARY.icon} />
        </span>

        <span className="land-hero-text">
          <span className="land-hero-title">{PRIMARY.label}</span>
          <span className="land-hero-blurb">{PRIMARY.blurb}</span>
        </span>

        <span className="land-hero-action">
          Start a resume <span aria-hidden="true">&rarr;</span>
        </span>
      </button>

      <button
        type="button"
        className="land-hero land-hero-secondary"
        onClick={() => go(analyse)}
      >
        <span className="land-hero-icon" aria-hidden="true">
          <Icon name={analyse.icon} />
        </span>

        <span className="land-hero-text">
          <span className="land-hero-title">{analyse.label}</span>
          <span className="land-hero-blurb">
            Upload your resume to understand your skills, improve your
            content, and review ATS compatibility.
          </span>
        </span>

        <span className="land-hero-action">
          Analyse Resume <span aria-hidden="true">&rarr;</span>
        </span>
      </button>

      <h2 className="land-section">Everything else</h2>

      <ul className="land-grid">
        {rest.map((feature) => (
          <li key={feature.key}>
            <button
              type="button"
              className="land-card"
              onClick={() => go(feature)}
            >
              <span className="land-card-icon" aria-hidden="true">
                <Icon name={feature.icon} />
              </span>

              <span className="land-card-title">{feature.label}</span>
              <span className="land-card-blurb">{feature.blurb}</span>
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}