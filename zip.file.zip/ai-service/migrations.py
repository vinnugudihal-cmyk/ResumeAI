"""
Versioned database migrations.

The original schema was created with a plain CREATE TABLE script
plus a hand-maintained list of ALTER TABLE statements. That does
not scale, so migrations are now numbered steps recorded in
SQLite's own ``user_version``.

Rules followed here:

* Every step is a list of plain SQL statements, applied in order.
* Steps are only ever appended. Existing steps are never edited,
  so a database created by an older build keeps its history.
* A consistent backup is taken before the first pending step runs.
  ``VACUUM INTO`` is used rather than a file copy because the
  database runs in WAL mode: a plain copy can miss rows still
  held in the -wal file and produce a backup that looks valid
  but is incomplete.
* Nothing destructive happens automatically. Existing rows are
  never dropped or rewritten.

This module depends on database.py for the connection helper.
database.py never imports this module, so there is no cycle.
app.py calls run() once at start-up.
"""

import os
import re
import shutil
import sqlite3
from datetime import datetime

import database


# ============================================================
# MIGRATION STEPS  (append only)
# ============================================================

MIGRATIONS = [
    (
        1,
        "baseline_resume_analysis",
        [
            """
            CREATE TABLE IF NOT EXISTS users (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                name          TEXT    NOT NULL DEFAULT 'Student',
                email         TEXT    NOT NULL UNIQUE,
                password_hash TEXT,
                created_at    TEXT    NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS resumes (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id        INTEGER NOT NULL
                               REFERENCES users(id) ON DELETE CASCADE,
                filename       TEXT    NOT NULL,
                stored_path    TEXT,
                file_size      INTEGER NOT NULL DEFAULT 0,
                mime_type      TEXT    NOT NULL DEFAULT 'application/pdf',
                text_length    INTEGER NOT NULL DEFAULT 0,
                text_excerpt   TEXT,
                uploaded_at    TEXT    NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS resume_analyses (
                id                     INTEGER PRIMARY KEY
                                           AUTOINCREMENT,
                resume_id              INTEGER NOT NULL
                                           REFERENCES resumes(id)
                                           ON DELETE CASCADE,
                user_id                INTEGER NOT NULL
                                           REFERENCES users(id)
                                           ON DELETE CASCADE,
                score                  INTEGER NOT NULL DEFAULT 0,
                ats_score              INTEGER NOT NULL DEFAULT 0,
                skills_json            TEXT NOT NULL DEFAULT '[]',
                matched_keywords_json  TEXT NOT NULL DEFAULT '[]',
                missing_keywords_json  TEXT NOT NULL DEFAULT '[]',
                suggestions_json       TEXT NOT NULL DEFAULT '[]',
                weaknesses_json        TEXT NOT NULL DEFAULT '[]',
                missing_sections_json  TEXT NOT NULL DEFAULT '[]',
                criteria_json          TEXT NOT NULL DEFAULT '{}',
                breakdown_json         TEXT NOT NULL DEFAULT '{}',
                improvement_plan_json  TEXT NOT NULL DEFAULT '[]',
                job_description        TEXT,
                result_json            TEXT NOT NULL DEFAULT '{}',
                created_at             TEXT    NOT NULL
            )
            """,
            "CREATE INDEX IF NOT EXISTS idx_resumes_user "
            "ON resumes(user_id, uploaded_at DESC)",
            "CREATE INDEX IF NOT EXISTS idx_analyses_user "
            "ON resume_analyses(user_id, created_at DESC)",
            "CREATE INDEX IF NOT EXISTS idx_analyses_resume "
            "ON resume_analyses(resume_id)",
        ],
    ),
    (
        2,
        "career_profile",
        [
            # One row per user. A brand new account has no row
            # until they save something, so an untouched
            # workspace is genuinely empty rather than prefilled.
            """
            CREATE TABLE IF NOT EXISTS career_profiles (
                id                  INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id             INTEGER NOT NULL UNIQUE
                                    REFERENCES users(id)
                                    ON DELETE CASCADE,
                full_name           TEXT,
                headline            TEXT,
                email               TEXT,
                phone               TEXT,
                location            TEXT,
                preferred_locations TEXT,
                work_arrangement    TEXT,
                portfolio_url       TEXT,
                linkedin_url        TEXT,
                github_url          TEXT,
                summary             TEXT,
                interests           TEXT,
                preferred_roles     TEXT,
                willing_to_relocate INTEGER NOT NULL DEFAULT 0,
                open_to_internship  INTEGER NOT NULL DEFAULT 0,
                created_at          TEXT    NOT NULL,
                updated_at          TEXT    NOT NULL
            )
            """,
            # One typed child table so education, projects,
            # experience, certifications and achievements can all
            # live together without a column per kind.
            """
            CREATE TABLE IF NOT EXISTS career_profile_items (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER NOT NULL
                            REFERENCES users(id) ON DELETE CASCADE,
                profile_id  INTEGER NOT NULL
                            REFERENCES career_profiles(id)
                            ON DELETE CASCADE,
                item_type   TEXT    NOT NULL,
                title       TEXT    NOT NULL,
                organisation TEXT,
                location    TEXT,
                start_date  TEXT,
                end_date    TEXT,
                is_current  INTEGER NOT NULL DEFAULT 0,
                description TEXT,
                url         TEXT,
                sort_order  INTEGER NOT NULL DEFAULT 0,
                created_at  TEXT    NOT NULL,
                updated_at  TEXT    NOT NULL
            )
            """,
            "CREATE INDEX IF NOT EXISTS idx_profile_items_user "
            "ON career_profile_items(user_id, item_type, sort_order)",
            "CREATE INDEX IF NOT EXISTS idx_profile_items_profile "
            "ON career_profile_items(profile_id)",
        ],
    ),
    (
        3,
        "career_mission",
        [
            # Skills the user declares themselves. Kept as free text
            # because ResumeAI never invents or validates a claim:
            # the user writes what they can actually do.
            "ALTER TABLE career_profiles "
            "ADD COLUMN skills TEXT",
            # One mission per target role. Re-selecting a role the
            # user already has a mission for returns the existing
            # one instead of creating a duplicate.
            """
            CREATE TABLE IF NOT EXISTS career_missions (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id        INTEGER NOT NULL
                               REFERENCES users(id)
                               ON DELETE CASCADE,
                role_key       TEXT    NOT NULL,
                role_title     TEXT    NOT NULL,
                job_title      TEXT,
                job_reference  TEXT,
                status         TEXT    NOT NULL DEFAULT 'active',
                readiness_json TEXT    NOT NULL DEFAULT '{}',
                created_at     TEXT    NOT NULL,
                updated_at     TEXT    NOT NULL
            )
            """,
            # user_id is repeated here on purpose. It is redundant
            # with mission_id, but it lets every task query check
            # ownership directly instead of relying on a join, so a
            # missing join can never widen access.
            """
            CREATE TABLE IF NOT EXISTS mission_tasks (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                mission_id   INTEGER NOT NULL
                             REFERENCES career_missions(id)
                             ON DELETE CASCADE,
                user_id      INTEGER NOT NULL
                             REFERENCES users(id)
                             ON DELETE CASCADE,
                task_key     TEXT    NOT NULL,
                title        TEXT    NOT NULL,
                detail       TEXT,
                category     TEXT    NOT NULL,
                skill        TEXT,
                importance   TEXT    NOT NULL DEFAULT 'preferred',
                status       TEXT    NOT NULL DEFAULT 'not_started',
                sort_order   INTEGER NOT NULL DEFAULT 0,
                completed_at TEXT,
                created_at   TEXT    NOT NULL,
                updated_at   TEXT    NOT NULL
            )
            """,
            "CREATE INDEX IF NOT EXISTS idx_missions_user "
            "ON career_missions(user_id, status, updated_at DESC)",
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_missions_user_role "
            "ON career_missions(user_id, role_key)",
            "CREATE INDEX IF NOT EXISTS idx_tasks_mission "
            "ON mission_tasks(mission_id, sort_order)",
            "CREATE INDEX IF NOT EXISTS idx_tasks_user "
            "ON mission_tasks(user_id, status)",
        ],
    ),
    (
        4,
        "resume_builder",
        [
            # Built resumes live in their own table. The existing
            # 'resumes' table holds uploaded PDFs for analysis and is
            # left completely untouched, so this feature can never
            # interfere with the analyser or its history.
            """
            CREATE TABLE IF NOT EXISTS saved_resumes (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id       INTEGER NOT NULL
                              REFERENCES users(id)
                              ON DELETE CASCADE,
                title         TEXT    NOT NULL DEFAULT 'Untitled Resume',
                template_key  TEXT    NOT NULL DEFAULT 'ats_classic',
                target_role   TEXT,
                content_json  TEXT    NOT NULL DEFAULT '{}',
                settings_json TEXT    NOT NULL DEFAULT '{}',
                created_at    TEXT    NOT NULL,
                updated_at    TEXT    NOT NULL
            )
            """,
            "CREATE INDEX IF NOT EXISTS idx_saved_resumes_user "
            "ON saved_resumes(user_id, updated_at DESC)",
            "CREATE INDEX IF NOT EXISTS idx_saved_resumes_template "
            "ON saved_resumes(user_id, template_key)",
        ],
    ),
    (
        5,
        "jobs_passport_tracker",
        [
            # Skill Passport. 'self_reported' is something the user
            # typed; 'submitted' is a project, repository or
            # certificate they actually added. The two are kept apart
            # because listing a skill is not the same as showing it.
            """
            CREATE TABLE IF NOT EXISTS skill_evidence (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id       INTEGER NOT NULL
                              REFERENCES users(id) ON DELETE CASCADE,
                kind          TEXT    NOT NULL DEFAULT 'project',
                title         TEXT    NOT NULL,
                description   TEXT,
                url           TEXT,
                organisation  TEXT,
                started_on    TEXT,
                completed_on  TEXT,
                skills_json   TEXT    NOT NULL DEFAULT '[]',
                evidence_type TEXT    NOT NULL DEFAULT 'self_reported',
                verified      INTEGER NOT NULL DEFAULT 0,
                sort_order    INTEGER NOT NULL DEFAULT 0,
                created_at    TEXT    NOT NULL,
                updated_at    TEXT    NOT NULL
            )
            """,
            "CREATE INDEX IF NOT EXISTS idx_evidence_user "
            "ON skill_evidence(user_id, kind, sort_order)",
            # Saved jobs. ResumeAI never stores a job it invented, so
            # source always records where a listing really came from.
            """
            CREATE TABLE IF NOT EXISTS saved_jobs (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id      INTEGER NOT NULL
                             REFERENCES users(id) ON DELETE CASCADE,
                title        TEXT    NOT NULL,
                company      TEXT,
                location     TEXT,
                work_mode    TEXT,
                employment   TEXT,
                salary       TEXT,
                source       TEXT    NOT NULL DEFAULT 'external_link',
                url          TEXT,
                description  TEXT,
                posted_on    TEXT,
                search_query TEXT,
                notes        TEXT,
                created_at   TEXT    NOT NULL,
                updated_at   TEXT    NOT NULL
            )
            """,
            "CREATE INDEX IF NOT EXISTS idx_saved_jobs_user "
            "ON saved_jobs(user_id, updated_at DESC)",
            # Application tracker. Notes stay private to the owner.
            """
            CREATE TABLE IF NOT EXISTS applications (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id      INTEGER NOT NULL
                             REFERENCES users(id) ON DELETE CASCADE,
                saved_job_id INTEGER REFERENCES saved_jobs(id)
                             ON DELETE SET NULL,
                resume_id    INTEGER REFERENCES saved_resumes(id)
                             ON DELETE SET NULL,
                mission_id   INTEGER REFERENCES career_missions(id)
                             ON DELETE SET NULL,
                job_title    TEXT    NOT NULL,
                company      TEXT,
                location     TEXT,
                work_mode    TEXT,
                employment   TEXT,
                salary       TEXT,
                apply_url    TEXT,
                status       TEXT    NOT NULL DEFAULT 'interested',
                applied_on   TEXT,
                next_step    TEXT,
                notes        TEXT,
                created_at   TEXT    NOT NULL,
                updated_at   TEXT    NOT NULL
            )
            """,
            "CREATE INDEX IF NOT EXISTS idx_applications_user "
            "ON applications(user_id, status, updated_at DESC)",
            # Status history, so a rejection traces back to when the
            # application was actually sent.
            """
            CREATE TABLE IF NOT EXISTS application_events (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                application_id INTEGER NOT NULL
                               REFERENCES applications(id)
                               ON DELETE CASCADE,
                user_id        INTEGER NOT NULL
                               REFERENCES users(id) ON DELETE CASCADE,
                status         TEXT    NOT NULL,
                note           TEXT,
                event_date     TEXT,
                created_at     TEXT    NOT NULL
            )
            """,
            "CREATE INDEX IF NOT EXISTS idx_app_events "
            "ON application_events(application_id, created_at DESC)",
        ],
    ),
    (
        6,
        "session_revocation",
        [
            # Flask's session is a client-side signed cookie, so
            # clearing it only asks the browser to replace it. A copy
            # taken before logout stays valid until it expires.
            # This counter is what makes signing out actually
            # revoke: it is bumped on logout and stored in the
            # cookie, so every session issued before that point
            # stops being accepted.
            "ALTER TABLE users "
            "ADD COLUMN session_version INTEGER NOT NULL DEFAULT 0",
        ],
    ),
]

LATEST_VERSION = max(version for version, _n, _s in MIGRATIONS)


# ============================================================
# BACKUP
# ============================================================

def backup_dir():
    """
    Backups live in a 'backups' folder beside the database file.

    Deliberately derived from DB_PATH rather than this module's own
    folder: when RESUMEAI_DB points somewhere else (a test copy, a
    staging file), the backup must follow the database it copies.
    Writing test backups into the real backups folder would quietly
    fill it with unrelated files.
    """

    directory = os.path.dirname(os.path.abspath(database.DB_PATH))

    return os.path.join(directory, "backups")


def create_backup(label="pre-migration"):
    """
    Write a consistent copy of the database and return its path.
    """

    target_dir = backup_dir()
    os.makedirs(target_dir, exist_ok=True)

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    target = os.path.join(
        target_dir, f"resumeai-{label}-{stamp}.db"
    )

    conn = database.get_connection()

    try:
        try:
            conn.execute("VACUUM INTO ?", (target,))
        except sqlite3.OperationalError as error:
            print(
                "VACUUM INTO unavailable, falling back to a "
                f"file copy: {error}"
            )
            shutil.copy2(database.DB_PATH, target)
        else:
            print(f"Database backed up to {target}")

    finally:
        conn.close()

    return target


# ============================================================
# RUNNER
# ============================================================

def current_version(conn):
    return conn.execute("PRAGMA user_version").fetchone()[0]


def pending_steps(conn):
    version = current_version(conn)

    return [
        (v, name, statements)
        for v, name, statements in MIGRATIONS
        if v > version
    ]


def row_count(conn, table):
    try:
        return conn.execute(
            f'SELECT COUNT(*) FROM "{table}"'
        ).fetchone()[0]
    except sqlite3.Error:
        return 0


def _summary(statement):
    """A short, log-friendly form of one statement."""

    collapsed = " ".join(statement.split())

    return collapsed if len(collapsed) <= 60 else collapsed[:57] + "..."


# ALTER TABLE ... ADD COLUMN ... has no IF NOT EXISTS form in
# SQLite, so a step that adds a column is the one kind of statement
# that cannot simply be repeated.
ADD_COLUMN = re.compile(
    r"^\s*ALTER\s+TABLE\s+(\w+)\s+ADD\s+(?:COLUMN\s+)?(\w+)",
    re.IGNORECASE,
)


def column_already_present(conn, statement):
    """
    True when a statement is an ADD COLUMN that has already been run.

    ``user_version`` is the only record of which steps ran, so a
    database whose schema is ahead of its recorded version - an
    interrupted upgrade, or a restore from a partial backup - would
    replay a step and abort on "duplicate column name". Checking the
    table first lets the run finish instead.
    """

    match = ADD_COLUMN.match(statement)

    if not match:
        return False

    table, column = match.group(1), match.group(2)

    # The table name comes from this module's own migration list, not
    # from input, and PRAGMA does not accept a bound parameter.
    if not re.fullmatch(r"\w+", table):
        return False

    return any(
        row["name"] == column
        for row in conn.execute(f"PRAGMA table_info({table})")
    )


def run(verbose=True):
    """
    Apply every pending migration step and return a report.
    """

    # Make sure the base tables exist first, so a brand new
    # install can be migrated straight to the latest version.
    database.init_db()

    conn = database.get_connection()

    report = {
        "from_version": current_version(conn),
        "to_version": current_version(conn),
        "applied": [],
        "backup": None,
        "latest": LATEST_VERSION,
    }

    steps = pending_steps(conn)

    if not steps:
        if verbose:
            print(
                "Database schema up to date "
                f"(version {report['from_version']})"
            )
        conn.close()
        return report

    # Only back up when there is real data worth protecting.
    existing_rows = sum(
        row_count(conn, table)
        for table in ("users", "resumes", "resume_analyses")
    )

    if existing_rows:
        conn.close()
        report["backup"] = create_backup()
        conn = database.get_connection()

    for version, name, statements in steps:

        if verbose:
            print(f"Applying migration {version}: {name}")

        try:
            for statement in statements:
                if column_already_present(conn, statement):
                    # Reported loudly rather than skipped quietly: a
                    # repeated step means the recorded version and
                    # the actual schema have drifted apart.
                    if verbose:
                        print(
                            "  column already exists, step not "
                            f"repeated: {_summary(statement)}"
                        )

                    continue

                conn.execute(statement)

            conn.execute(f"PRAGMA user_version = {version}")
            conn.commit()

        except sqlite3.Error as error:
            conn.rollback()
            conn.close()
            raise RuntimeError(
                f"Migration {version} ({name}) failed: {error}"
            ) from error

        report["applied"].append(
            {"version": version, "name": name}
        )

    report["to_version"] = current_version(conn)
    conn.close()

    if verbose:
        print(f"Database now at version {report['to_version']}")

    return report
