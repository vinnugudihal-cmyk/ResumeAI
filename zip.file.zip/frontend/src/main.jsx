import React from "react";
import ReactDOM from "react-dom/client";

import App from "./App.jsx";

import "./index.css";

/*
 * Imported last, on purpose.
 *
 * Every page stylesheet is pulled in by App.jsx above, so anything
 * imported here lands after all of them. The shared theme is the
 * app's decision about what it looks like; the per-page files are
 * older and more specific, but on a shared property such as the
 * page background they must not keep overriding it page by page.
 */
import "./theme.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);